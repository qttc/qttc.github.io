#!/system/bin/sh

# Standalone 5 GHz SoftAP installer and rollback script for the head unit.

PATH=/system/bin:/system/xbin
BB="$(command -v busybox 2>/dev/null)"
[ -x "$BB" ] || BB=/system/xbin/busybox
[ -x "$BB" ] || BB=/system/bin/busybox
HOSTAPD=/system/bin/hostapd
BACKUP=/system/bin/hostapd.community-stock
STATE=/data/misc/wifi/community_ap_band
PREVIOUS_STATE=/data/misc/wifi/community_ap_band.community-prev
INTERNAL_LOG=/data/misc/wifi/community_ap_band.log
USB_LOG=/udisk/single/hostapd_5ghz_patch.log
INTERNAL_STATUS=/data/misc/wifi/community_ap_status.txt
USB_STATUS=/udisk/single/OH_COOLRAY_STATUS.txt
WRAPPER_MARKER=COMMUNITY_AP_BAND_WRAPPER_V1
BAND_MARKER=/data/local/tmp/oh_hostapd_band
FAILED_FLAG=/data/misc/wifi/community_ap_band.failed
VARIANT_FILE=/data/misc/wifi/community_ap_variant
FW_DEFAULTS_FILE=/data/misc/wifi/community_ap_fw_defaults
ROTATE_FILE=/data/misc/wifi/community_ap_rotations
# The driver downloads this NVRAM, path compiled into bcmdhd.ko, at every load; its ccode line
# picks the radio's region. The vendor's file is kept next to it while the patch is on.
NVRAM=/system/etc/wifi/bcmdhd.cal
NVRAM_BACKUP=/system/etc/wifi/bcmdhd.cal.community-stock
NVRAM_REGION=BY
NVRAM_REGREV=3
# What "check" asks of the radio: the chip, from the driver's info string while bcmdhd is
# loaded, and the 20 MHz channel the access point uses, in the region above.
DRIVER_INFO=/sys/module/bcmdhd/parameters/info_string
CHECK_CHIP=4339
CHECK_CHANNEL=36
# Byte sizes of the Wi-Fi files on the units this patch was proven on (2026-11, two units with
# builds H40.00022 and H50.00020): firmware 6.37.47.1, its driver, hostapd and netd.
KNOWN_WIFI_SIZES="fw_bcmdhd.bin=562718 fw_bcmdhd_apsta.bin=513350 bcmdhd.ko=722678 hostapd=387856 netd=71300"
SYSTEM_RW=0

bb() { "$BB" "$@"; }

record() {
	priority="$1"
	shift
	message="$*"
	stamp="$(date)"
	line="$stamp $message"
	[ -d /data/misc/wifi ] && echo "$line" >> "$INTERNAL_LOG" 2>/dev/null
	[ -d /udisk/single ] && echo "$line" >> "$USB_LOG" 2>/dev/null
	/system/bin/log -p "$priority" -t Hostapd5GHz "$message" 2>/dev/null
}

status_message() {
	line="$(date) $*"
	[ -d /data/misc/wifi ] && echo "$line" >> "$INTERNAL_STATUS" 2>/dev/null
	[ -d /udisk/single ] && echo "$line" >> "$USB_STATUS" 2>/dev/null
}

say() {
	echo "[hostapd-5ghz] $*"
	record i "$*"
	status_message "INSTALLER: $*"
}

fail() {
	echo "[hostapd-5ghz] ERROR: $*"
	record e "ERROR: $*"
	status_message "INSTALLER_ERROR: $*"
	exit 1
}

if [ ! -x "$BB" ]; then
	fail "BusyBox is required on this Android 4.3 image."
fi

remount_system_ro() {
	if [ "$SYSTEM_RW" = 1 ]; then
		mount -o remount,ro /system >/dev/null 2>&1
		SYSTEM_RW=0
	fi
}

trap 'remount_system_ro' 0
trap 'remount_system_ro; exit 1' 1 2 15

usage() {
	echo "Usage: sh hostapd_5ghz_usb.sh install [channel]"
	echo "       sh hostapd_5ghz_usb.sh rollback"
	echo "       sh hostapd_5ghz_usb.sh check    (read-only: whether install can run here)"
	echo "Allowed 5 GHz channels: 36,40,44,48"
	echo "install also sets the radio region in $NVRAM to $NVRAM_REGION/$NVRAM_REGREV; rollback restores the vendor's file."
}

write_wrapper() {
	cat > "$1" <<'HOSTAPD_WRAPPER'
#!/system/bin/sh
# COMMUNITY_AP_BAND_WRAPPER_V1

PATH=/system/bin:/system/xbin
BB="$(command -v busybox 2>/dev/null)"
[ -x "$BB" ] || BB=/system/xbin/busybox
[ -x "$BB" ] || BB=/system/bin/busybox
REAL_HOSTAPD=/system/bin/hostapd.community-stock
STATE=/data/misc/wifi/community_ap_band
PREVIOUS_STATE=/data/misc/wifi/community_ap_band.community-prev
INTERNAL_LOG=/data/misc/wifi/community_ap_band.log
USB_LOG=/udisk/single/hostapd_5ghz_patch.log
INTERNAL_STATUS=/data/misc/wifi/community_ap_status.txt
USB_STATUS=/udisk/single/OH_COOLRAY_STATUS.txt
BAND_MARKER=/data/local/tmp/oh_hostapd_band
FAILED_FLAG=/data/misc/wifi/community_ap_band.failed
# Stations the firmware turns away, space-separated; none here. On the unit this was tuned on,
# one phone's home-network address left the access point within a second of every stall, so it
# was listed; add one only with that kind of evidence from this unit's logs.
AP_DENY_MACS=""
# Frame aggregation off at every start, stick or not. With it on, a frame this firmware dropped
# inside a Block Ack session left the S22 holding every later frame until 64 more arrived, which
# stalled each Android Auto session within 30 s (10-28 to 10-30, 6 of 6); with it off one session
# ran 62 min without a stall (10-30).
AMPDU_WANTED=0

bb() { "$BB" "$@"; }

log_message() {
	message="$*"
	line="$(date) $message"
	echo "$line" >> "$INTERNAL_LOG" 2>/dev/null
	[ -d /udisk/single ] && echo "$line" >> "$USB_LOG" 2>/dev/null
	/system/bin/log -p i -t Hostapd5GHz "$message" 2>/dev/null
}

status_message() {
	line="$(date) $*"
	echo "$line" >> "$INTERNAL_STATUS" 2>/dev/null
	[ -d /udisk/single ] && echo "$line" >> "$USB_STATUS" 2>/dev/null
}

# Tells OH Coolray which band hostapd starts on, then becomes it. exec keeps this pid, so the
# line "<hw_mode> <channel> <pid>" describes the running access point only while it is a hostapd.
run_hostapd() {
	umask 022
	if [ -n "$config" ]; then
		marked_mode="$(bb awk -F= '$1 == "hw_mode" { print $2; exit }' "$config")"
		marked_channel="$(bb awk -F= '$1 == "channel" { print $2; exit }' "$config")"
		echo "$marked_mode $marked_channel $$" > "$BAND_MARKER" 2>/dev/null
	else
		: > "$BAND_MARKER" 2>/dev/null
	fi
	# $debug_flag stays unquoted: empty, it adds no argument at all.
	exec "$REAL_HOSTAPD" $debug_flag "$@"
}
debug_flag=

if [ ! -x "$REAL_HOSTAPD" ]; then
	: > "$BAND_MARKER" 2>/dev/null
	log_message "ERROR: saved hostapd binary is missing."
	status_message "STATE=HOSTAPD_ERROR reason=stock_binary_missing"
	exit 127
fi

config=
for arg in "$@"; do
	if [ -f "$arg" ] && bb grep -q '^hw_mode=' "$arg" 2>/dev/null && \
		bb grep -q '^channel=' "$arg" 2>/dev/null; then
		config="$arg"
	fi
done

# Not an access point start (hostapd -v from the diagnostics, a help query): nothing to rewrite,
# and the marker belongs to the hostapd that is running, so it is left alone.
if [ -z "$config" ]; then
	exec "$REAL_HOSTAPD" "$@"
fi

if [ ! -r "$STATE" ]; then
	run_hostapd "$@"
fi

read mode channel < "$STATE"
case "$mode:$channel" in
	5:36|5:40|5:44|5:48)
		hw_mode=a
		;;
	*)
		log_message "ERROR: invalid saved band/channel; using stock hostapd."
		status_message "STATE=HOSTAPD_ERROR reason=invalid_saved_band_or_channel"
		run_hostapd "$@"
		;;
esac

# The firmware's region, 802.11n and bandwidth state, one line for the logs (read-only wl gets).
# Built up and echoed once: this unit's shell has no printf.
radio_caps() {
	caps=
	for q in country nmode nreqd mimo_bw_cap "bw_cap 2g" "bw_cap 5g"; do
		# $q stays unquoted: "bw_cap 2g" is two arguments.
		caps="$caps$q=$(wl $q 2>&1 | bb tr '\n' ' ') "
	done
	echo "$caps"
}

# Every chanspec the firmware's region allows, per band and width.
chanspec_lists() {
	lists=
	for b in 2 5; do
		for w in 20 40 80; do
			[ "$b$w" = 280 ] && continue
			lists="$lists$b GHz $w MHz: $(wl chanspecs -b $b -w $w 2>&1 | bb tr '\n' ' ')| "
		done
	done
	echo "$lists"
}

# With 802.11n off in the firmware's region the driver offers no HT, and the kernel refuses any
# channel hostapd asks for with ieee80211n=1 (26.10 under BY/0: -22 on 5 and 2.4 GHz alike), so
# the config then drops 802.11n. With nmode on, or not readable, the config is left alone.
drop_ht_if_off() {   # $1 config
	[ "$(wl nmode 2>/dev/null | bb tr -d ' \r\n')" = 0 ] || return 0
	ht_tmp="$1.community-ht.$$"
	if bb awk '/^ieee80211n=/ { print "ieee80211n=0"; next } { print }' "$1" > "$ht_tmp" && \
		! bb grep -q '^ieee80211n=1' "$ht_tmp" && cat "$ht_tmp" > "$1"; then
		log_message "firmware nmode=0: ieee80211n=0 written, so the access point runs without 802.11n."
		status_message "STATE=HOSTAPD_NO_HT reason=nmode_0"
	else
		log_message "ERROR: firmware nmode=0, but the config could not drop 802.11n; the kernel will likely refuse the channel."
	fi
	rm -f "$ht_tmp"
}

# 5 GHz stays on until the drops are debugged: a start that died is reported, then 5 GHz again.
if [ -f "$FAILED_FLAG" ]; then
	failed_start="$(cat "$FAILED_FLAG" 2>/dev/null)"
	rm -f "$FAILED_FLAG"
	log_message "the last 5 GHz start exited within 12 s ($failed_start); trying 5 GHz again."
	status_message "STATE=HOSTAPD_5GHZ_RETRY reason=previous_5ghz_start_died ($failed_start)"
fi

# The installer sets the region in the NVRAM (/system/etc/wifi/bcmdhd.cal), which the driver
# reads before it builds the kernel's channel list, so the radio normally reports BY already.
# Should it not (an NVRAM the installer could not change), the region is set here before
# hostapd, on the 5 GHz start only; that reaches the firmware but not the kernel's channel list.
AP_COUNTRY=BY
country_now() { wl country 2>&1 | bb tr '\n' ' '; }
has_country() { case "$(country_now)" in "$AP_COUNTRY "*) return 0 ;; esac; return 1; }

# One way of asking for the region: logs the command, its exit and output, and what the radio
# runs afterwards. Succeeds when the radio now reports the region.
try_country() {   # $1 label, then the command and its arguments
	try_label="$1"; shift
	try_out="$("$@" 2>&1)"; try_rc=$?
	log_message "region try $try_label: '$*' exit=$try_rc output=$(echo "$try_out" | bb tr '\n' ' ') now=$(country_now)"
	has_country
}

# The driver's own COUNTRY command, through netd (which needs /system/lib/libnetcmdiface.so for
# it): the driver then keeps the region across firmware reloads and rebuilds the kernel's
# channel list, which a plain wl country does not. Given 5 s; a netd that does not answer is
# killed so the access point start is never held up.
try_driver_country() {
	command -v ndc >/dev/null 2>&1 || { log_message "region try driver: ndc is not on this unit"; return 1; }
	ndc_out="$INTERNAL_LOG.ndc.$$"
	ndc interface driver wlan0 COUNTRY "$AP_COUNTRY" > "$ndc_out" 2>&1 &
	ndc_pid=$!; waited=0
	while kill -0 "$ndc_pid" 2>/dev/null && [ "$waited" -lt 5 ]; do sleep 1; waited=$((waited + 1)); done
	# Reaped here: after exec, hostapd would inherit it and never collect the zombie.
	kill -9 "$ndc_pid" 2>/dev/null; wait "$ndc_pid" 2>/dev/null
	log_message "region try driver: 'ndc interface driver wlan0 COUNTRY $AP_COUNTRY' waited=${waited}s output=$(bb tr '\n' ' ' < "$ndc_out" 2>/dev/null) now=$(country_now)"
	rm -f "$ndc_out"
	has_country
}

# Each way in turn until one takes, the driver's own command first; the radio's up/down state
# is put back after the last one.
set_country() {
	log_message "region before: $(country_now) isup=$(wl isup 2>&1) chan_info $channel: $(wl chan_info "$channel" 2>&1 | bb tr '\n' ' ')"
	log_message "radio before: $(radio_caps)"
	if has_country; then
		log_message "region is $AP_COUNTRY already (from the NVRAM); nothing to set."
		return 0
	fi
	log_message "netd's driver commands load $(ls -l /system/lib/libnetcmdiface.so 2>&1)"
	try_driver_country && return 0
	try_country plain wl country "$AP_COUNTRY" && return 0
	try_country rev0 wl country "$AP_COUNTRY/0" && return 0
	was_up="$(wl isup 2>/dev/null)"
	wl down > /dev/null 2>&1
	try_country radio_down wl country "$AP_COUNTRY"; down_rc=$?
	[ "$was_up" = 1 ] && wl up > /dev/null 2>&1
	return $down_rc
}

if set_country; then
	status_message "STATE=HOSTAPD_COUNTRY_SET wanted=$AP_COUNTRY now=$(country_now)"
else
	# The 5 GHz start goes ahead: hostapd -d then logs exactly why the channel is refused, and a
	# failure is flagged below, and the next start tries 5 GHz again.
	log_message "ERROR: no way of setting region $AP_COUNTRY worked; starting 5 GHz anyway for hostapd's own log."
	status_message "STATE=HOSTAPD_COUNTRY_NOT_SET wanted=$AP_COUNTRY now=$(country_now)"
fi
log_message "region after: $(country_now) chan_info $channel: $(wl chan_info "$channel" 2>&1 | bb tr '\n' ' ') spect: $(wl spect 2>&1 | bb tr '\n' ' ') isup=$(wl isup 2>&1) ap=$(wl ap 2>&1)"
log_message "radio after: $(radio_caps)"
log_message "chanspecs: $(chanspec_lists)"

config_tmp="$config.community-tmp.$$"
umask 077
# awk rather than sed: busybox awk has run on this unit, busybox sed never has.
if ! bb awk -v mode="$hw_mode" -v chan="$channel" '
	/^hw_mode=/ { print "hw_mode=" mode; next }
	/^channel=/ { print "channel=" chan; next }
	{ print }' "$config" > "$config_tmp"; then
	rm -f "$config_tmp"
	log_message "ERROR: config rewrite failed; using stock config."
	status_message "STATE=HOSTAPD_ERROR reason=config_rewrite_failed"
	run_hostapd "$@"
fi

# Written in place, not moved: the file keeps netd's owner and mode (system:wifi 0660),
# and no chown is needed, which would fail if this wrapper runs as the wifi user.
if ! bb grep -q "^hw_mode=$hw_mode$" "$config_tmp" || \
	! bb grep -q "^channel=$channel$" "$config_tmp" || \
	! cat "$config_tmp" > "$config"; then
	rm -f "$config_tmp"
	log_message "ERROR: rewritten config validation failed; using stock config."
	status_message "STATE=HOSTAPD_ERROR reason=config_validation_failed"
	run_hostapd "$@"
fi
rm -f "$config_tmp"

log_message "Applied hw_mode=$hw_mode channel=$channel."
status_message "STATE=HOSTAPD_CONFIG_APPLIED hw_mode=$hw_mode channel=$channel"
drop_ht_if_off "$config"

wl_value() { wl "$1" 2>/dev/null | bb tr -d ' \r\n'; }

# One setting before hostapd. A setting the firmware takes only with the radio down gets a
# down/up around it, and the radio is left up or down as it was.
apply_setting() {   # $1 setting, $2 value
	wl "$1" "$2" >/dev/null 2>&1 && return 0
	setting_was_up="$(wl isup 2>/dev/null)"
	wl down >/dev/null 2>&1
	wl "$1" "$2" >/dev/null 2>&1; setting_rc=$?
	[ "$setting_was_up" = 1 ] && wl up >/dev/null 2>&1
	return $setting_rc
}

# Aggregation to AMPDU_WANTED before hostapd brings the access point up; already there, nothing
# is touched. A refusing firmware is reported and the access point starts all the same.
if [ "$(wl_value ampdu)" = "$AMPDU_WANTED" ] || apply_setting ampdu "$AMPDU_WANTED"; then
	status_message "STATE=HOSTAPD_AMPDU_OFF ampdu=$(wl_value ampdu)"
else
	status_message "STATE=HOSTAPD_AMPDU_FAILED ampdu=$(wl_value ampdu); the firmware refused ampdu $AMPDU_WANTED, Android Auto may stall again"
fi
log_message "frame aggregation before hostapd: ampdu=$(wl_value ampdu)"
# The newest file of the vendor's kernel log store: c3_kernel_store drains dmesg into it every
# 3 s, so the driver's CFG80211 lines about this access point start end up there.
kernel_store_tail() {
	newest=; newest_n=-1
	for f in /data/c3_kernel_logs/*.log; do
		[ -f "$f" ] || continue
		n=${f##*/}; n=${n%%_*}
		case "$n" in ''|*[!0-9]*) continue ;; esac
		[ "$n" -gt "$newest_n" ] && { newest_n=$n; newest=$f; }
	done
	[ -n "$newest" ] || { echo "(no file in /data/c3_kernel_logs)"; return 0; }
	echo "-- $newest, last 600 lines"; bb tail -n 600 "$newest"
}

radio_state() {
	echo "wl country: $(country_now)"; echo "wl chanspec: $(wl chanspec 2>&1 | bb tr '\n' ' ')"
	echo "wl isup: $(wl isup 2>&1 | bb tr '\n' ' ') wl ap: $(wl ap 2>&1 | bb tr '\n' ' ')"
	echo "radio: $(radio_caps)"
	echo "config: $(bb grep -E '^(hw_mode|channel|ieee80211n|ht_capab)=' "$config" 2>&1 | bb tr '\n' ' ')"
	echo "mac filter: $(mac_deny_state)"
}

mac_deny_state() { echo "macmode=$(wl macmode 2>&1 | bb tr '\n' ' ') list=$(wl mac 2>&1 | bb tr '\n' ' ')"; }

# At the firmware, because hostapd cannot: bcmdhd associates stations in the firmware and takes
# no MAC list from hostapd, which never even sees such a station. Every start reloads the firmware, so
# every start sets it again; a firmware or wl that refuses it leaves the access point as it is.
apply_mac_deny() {
	[ -n "$AP_DENY_MACS" ] || return 0
	if wl macmode 1 >/dev/null 2>&1 && wl mac $AP_DENY_MACS >/dev/null 2>&1; then
		status_message "STATE=HOSTAPD_MAC_DENY macs=$AP_DENY_MACS $(mac_deny_state)"
	else
		status_message "STATE=HOSTAPD_MAC_DENY_FAILED macs=$AP_DENY_MACS $(mac_deny_state)"
	fi
}

# One look at each step of the way to the phone: what the kernel handed the driver (wlan0), what
# the firmware holds and sent per station (power save, packets, failures, queues) and the
# firmware's own counters. A stall then shows which step stopped passing frames on.
radio_sample() {
	echo "== $(date) uptime=$(cat /proc/uptime 2>&1)"
	netdev=
	for s in tx_packets tx_dropped tx_errors rx_packets rx_dropped; do
		netdev="$netdev $s=$(cat /sys/class/net/wlan0/statistics/$s 2>&1)"
	done
	echo "wlan0:$netdev"
	stations="$(wl assoclist 2>&1)"
	echo "assoclist: $(echo "$stations" | bb tr '\n' ' ')"
	for sta in $(echo "$stations" | bb awk '{ print $NF }'); do
		echo "-- sta_info $sta"; wl sta_info "$sta" 2>&1
		echo "-- pktq_stats a:$sta"; wl pktq_stats "a:$sta" 2>&1
	done
	echo "-- counters"; wl counters 2>&1
}

# For as long as this hostapd runs and a stick is in: the radio every 2 s, and the hostapd, netd
# and Wi-Fi framework lines as they happen. A stall then shows whether the phone dozed, the air
# failed or a second station came, at any point of the drive rather than in the first minute.
radio_watch() {
	[ -d /udisk/single ] || return 0
	logcat -v threadtime hostapd:V Hostapd5GHz:V SoftapController:V WifiStateMachine:V WifiHW:V \
		Tethering:V dnsmasq:V '*:S' > "/udisk/single/OH_hostapd_${wrapper_pid}_events.txt" 2>&1 &
	events_pid=$!
	echo "== ampdu=$(wl_value ampdu)" >> "/udisk/single/OH_radio_$wrapper_pid.txt" 2>&1
	while [ -d /udisk/single ] && bb grep -q hostapd "/proc/$wrapper_pid/cmdline" 2>/dev/null; do
		radio_sample >> "/udisk/single/OH_radio_$wrapper_pid.txt" 2>&1
		sleep 2
	done
	kill "$events_pid" 2>/dev/null; kill -9 "$events_pid" 2>/dev/null; wait "$events_pid" 2>/dev/null
}

# What this 5 GHz start left in the logs, onto the stick when one is in: the radio state, the
# hostapd, netd and Wi-Fi HAL lines still in logcat, dmesg and the kernel store's tail.
start_report() {
	[ -d /udisk/single ] || return 0
	{
		echo "== $(date) hostapd pid $wrapper_pid, channel $channel, 12 s after the start"; radio_state
		echo "== logcat -d (hostapd, netd SoftAP, Wi-Fi HAL and framework lines; all of it, live, in OH_hostapd_start_${wrapper_pid}_logcat.txt)"
		logcat -d -v threadtime 2>&1 | bb grep -i -E 'hostapd|Hostapd5GHz|SoftapController|WifiHW|WifiStateMachine|nl80211'
		echo "== dmesg (empty when the vendor's kernel store has drained it)"; dmesg 2>&1
		echo "== vendor kernel store"; kernel_store_tail
	} > "/udisk/single/OH_hostapd_start_$wrapper_pid.txt" 2>&1
}

# Judged on whether hostapd outlived its start, not on wl: this may run as the wifi user, which
# the driver refuses. A hostapd that died stays in ps as an unreaped zombie, so those do not count.
wrapper_pid=$$
(
	# Everything logcat sees for a minute from this start, written as it happens: a dump taken
	# later comes too late, because the boot refills the buffer within seconds.
	live_log=
	if [ -d /udisk/single ]; then
		live_log="/udisk/single/OH_hostapd_start_${wrapper_pid}_logcat.txt"
		logcat -v threadtime > "$live_log" 2>&1 &
		logcat_pid=$!
	fi
	# The deny list goes in once hostapd has the access point up; such a station came ~30 s after the start.
	sleep 3
	apply_mac_deny
	# hostapd's own bring-up may reset what was set before it. Read only: setting it now would
	# need the radio down, which would take the access point with it.
	status_message "STATE=HOSTAPD_AMPDU_AFTER_START ampdu=$(wl_value ampdu)"
	radio_watch &
	sleep 9
	if bb grep -q hostapd "/proc/$wrapper_pid/cmdline" 2>/dev/null; then
		active_channel="$(wl chanspec 2>/dev/null | bb tr '\n' ' ')"
		[ -n "$active_channel" ] || active_channel=unreadable
		status_message "STATE=HOSTAPD_5GHZ_RUNNING hw_mode=$hw_mode channel=$channel pid=$wrapper_pid active_channel=$active_channel country=$(wl country 2>&1 | bb tr '\n' ' ')"
	elif ps | bb awk '$8 != "Z" && $9 ~ /hostapd/ { found = 1 } END { exit !found }'; then
		status_message "STATE=HOSTAPD_5GHZ_REPLACED channel=$channel pid=$wrapper_pid; a newer hostapd is running, nothing to judge"
	else
		echo "$(date) channel=$channel pid=$wrapper_pid" > "$FAILED_FLAG" 2>/dev/null
		log_message "ERROR: hostapd on 5 GHz channel $channel exited within 12 s; the next start tries 5 GHz again."
		status_message "STATE=HOSTAPD_5GHZ_FAILED channel=$channel country=$(wl country 2>&1 | bb tr '\n' ' '); the next access point start tries 5 GHz again"
	fi
	start_report
	sync
	sleep 48
	if [ -n "$live_log" ]; then
		kill "$logcat_pid" 2>/dev/null; kill -9 "$logcat_pid" 2>/dev/null; wait "$logcat_pid" 2>/dev/null
		{ echo; echo "== $(date) 60 s after the start"; radio_state; echo "== vendor kernel store"; kernel_store_tail; } \
			>> "/udisk/single/OH_hostapd_start_$wrapper_pid.txt" 2>&1
	fi
	sync
) < /dev/null >/dev/null 2>&1 &
# -d on the 5 GHz start only: hostapd then logs the kernel's channel list with its
# DISABLED/NO_IR/RADAR flags and the exact reason for a failure. Keys stay out without -K.
debug_flag=-d
log_message "starting hostapd with -d for this 5 GHz start; its log goes to logcat and, with a stick in, live to OH_hostapd_start_${wrapper_pid}_logcat.txt."
run_hostapd "$@"
HOSTAPD_WRAPPER
}

is_root() {
	case "$(id 2>/dev/null)" in
		uid=0*) return 0 ;;
	esac
	return 1
}

require_root() {
	is_root || fail "run this script as root (for example through su)."
}

remount_system_rw() {
	mount -o remount,rw /system || fail "could not remount /system read-write."
	SYSTEM_RW=1
}

# Temp copies an interrupted or failed earlier run left in /system/bin and /data/misc/wifi.
# Needs /system read-write; an unmatched pattern stays literal and rm -f ignores it.
remove_leftovers() {
	rm -f "$HOSTAPD".community-tmp.* "$HOSTAPD".community-restore.* "$STATE".tmp.* \
		"$NVRAM".community-tmp.* "$NVRAM".community-restore.*
}

# An ELF binary starts with the bytes 127 'E' 'L' 'F'.
is_elf() {
	bb od -An -v -t u1 "$1" 2>/dev/null | bb head -n 1 | bb grep -qE '^ *127 +69 +76 +70( |$)'
}

# The saved hostapd must be the vendor's ELF binary, never the wrapper.
backup_is_original() {
	[ -x "$BACKUP" ] && ! bb grep -q "$WRAPPER_MARKER" "$BACKUP" 2>/dev/null && is_elf "$BACKUP"
}

# Only applets already seen working on this unit are used (awk, grep, head, od, tr); each is
# tried on real input here, before anything is changed, so a missing one stops a clean run.
check_tools() {
	[ "$(echo 'hw_mode=g' | bb awk -F= '$1 == "hw_mode" { print "hw_mode=a" }')" = "hw_mode=a" ] ||
		fail "busybox awk does not work on this unit; nothing was changed."
	echo 'channel=6' | bb grep -q '^channel=6$' || fail "busybox grep does not work on this unit; nothing was changed."
	[ "$( (echo first; echo second) | bb head -n 1)" = "first" ] ||
		fail "busybox head does not work on this unit; nothing was changed."
	echo x | bb od -An -v -t u1 | bb grep -qE '^ *120( |$)' ||
		fail "busybox od does not work on this unit; nothing was changed."
	[ "$(echo 'a b' | bb tr ' ' '_')" = "a_b" ] || fail "busybox tr does not work on this unit; nothing was changed."
	[ "$(echo abc | bb wc -c | bb tr -d ' ')" = 4 ] || fail "busybox wc does not work on this unit; nothing was changed."
	# The NVRAM checks find the CR of its CRLF lines through sprintf("%c", 13).
	[ "$(bb awk 'BEGIN { printf "%s", sprintf("%c", 65) }')" = A ] ||
		fail "busybox awk sprintf %c does not work on this unit; nothing was changed."
}

file_size() { bb wc -c < "$1" 2>/dev/null | bb tr -d ' '; }

# The values an NVRAM file sets for one key, one per line, without the CR of the vendor's CRLF
# endings.
nvram_values() {   # $1 key (ccode, regrev), $2 file
	bb awk -v key="$1=" 'BEGIN { cr = sprintf("%c", 13); n = length(key) }
		substr($0, 1, n) == key { v = substr($0, n + 1); if (substr(v, length(v)) == cr) v = substr(v, 1, length(v) - 1); print v }' "$2" 2>/dev/null
}

nvram_ccodes() { nvram_values ccode "$1"; }

# The vendor's file: present, not empty, one ccode line reading CN and one regrev line reading 0.
nvram_is_original() {
	[ -s "$1" ] && [ "$(nvram_values ccode "$1")" = "CN" ] && [ "$(nvram_values regrev "$1")" = 0 ]
}

# How many bytes differ between two files of the same size, compared through od.
bytes_differing() {
	{ bb od -An -v -t u1 "$1"; echo "=="; bb od -An -v -t u1 "$2"; } 2>/dev/null | bb awk '
		$1 == "==" { second = 1; i = 0; next }
		{ for (k = 1; k <= NF; k++) { i++; if (!second) a[i] = $k; else if (a[i] != $k) d++ } }
		END { print d + 0 }'
}

# $1 with its ccode=CN and regrev=0 lines set to the region and revision, every other byte kept:
# the lines are joined back with the newline awk split them at and each keeps its CR. awk cannot
# tell whether the last line had a newline, so the caller compares sizes and adds it if it did.
nvram_rewrite() {   # $1 source, $2 target
	bb awk -v region="$NVRAM_REGION" -v rev="$NVRAM_REGREV" '
		BEGIN { cr = sprintf("%c", 13) }
		{
			if (NR > 1) printf "\n"
			l = $0
			if (l == "ccode=CN") l = "ccode=" region
			else if (l == "ccode=CN" cr) l = "ccode=" region cr
			else if (l == "regrev=0") l = "regrev=" rev
			else if (l == "regrev=0" cr) l = "regrev=" rev cr
			printf "%s", l
		}' "$1" > "$2"
}

# The radio's region comes from the NVRAM the driver downloads at every load, and the vendor's
# CN/0 offers no 36-48: the driver builds the kernel's channel list from it before hostapd
# starts, so no later wl country can add them. BY/0 is no revision of the firmware's own table
# either (it has BY/3 only, with the 802.11n locales of DE/7), and with it the kernel refused
# every 802.11n channel, so the file gets BY/3. It is always built from the vendor's file, kept
# as the backup, and differs from it in the ccode letters and the regrev digit only.
nvram_patch() {
	if nvram_is_original "$NVRAM"; then
		cp -p "$NVRAM" "$NVRAM_BACKUP" || fail "could not save the original NVRAM."
		chmod 644 "$NVRAM_BACKUP" || fail "could not set NVRAM backup permissions."
	elif ! nvram_is_original "$NVRAM_BACKUP" || [ "$(nvram_ccodes "$NVRAM")" != "$NVRAM_REGION" ]; then
		fail "unexpected NVRAM at $NVRAM (ccode: $(nvram_ccodes "$NVRAM" | bb tr '\n' ' ') regrev: $(nvram_values regrev "$NVRAM" | bb tr '\n' ' ')); it was not changed."
	fi
	nvram_tmp="$NVRAM.community-tmp.$$"
	nvram_rewrite "$NVRAM_BACKUP" "$nvram_tmp" || { rm -f "$nvram_tmp"; fail "could not write the new NVRAM."; }
	size="$(file_size "$NVRAM_BACKUP")"
	[ "$(file_size "$nvram_tmp")" = $((size - 1)) ] && echo >> "$nvram_tmp"
	if [ "$(file_size "$nvram_tmp")" != "$size" ] || [ "$(nvram_ccodes "$nvram_tmp")" != "$NVRAM_REGION" ] || \
		[ "$(nvram_values regrev "$nvram_tmp")" != "$NVRAM_REGREV" ] || \
		[ "$(bytes_differing "$NVRAM_BACKUP" "$nvram_tmp")" != 3 ]; then
		rm -f "$nvram_tmp"
		fail "the new NVRAM did not check out (size, ccode, regrev or bytes changed); $NVRAM was not changed."
	fi
	# An earlier run may have left exactly this file; then nothing is replaced.
	if [ "$(file_size "$NVRAM")" = "$size" ] && [ "$(bytes_differing "$NVRAM" "$nvram_tmp")" = 0 ]; then
		rm -f "$nvram_tmp"
		say "NVRAM already sets $NVRAM_REGION/$NVRAM_REGREV; the vendor's file is kept at $NVRAM_BACKUP."
		return 0
	fi
	{ chmod 644 "$nvram_tmp" && chown 0:0 "$nvram_tmp"; } || { rm -f "$nvram_tmp"; fail "could not set NVRAM permissions."; }
	mv "$nvram_tmp" "$NVRAM" || fail "could not install the new NVRAM."
	say "NVRAM region set to $NVRAM_REGION/$NVRAM_REGREV ($size bytes, 3 changed from the vendor's); the vendor's file is kept at $NVRAM_BACKUP."
}

# The vendor's NVRAM back from the backup, checked byte for byte before it replaces the patched one.
nvram_restore() {
	if [ ! -e "$NVRAM_BACKUP" ]; then
		say "no NVRAM backup; $NVRAM left as it is (ccode lines: $(nvram_ccodes "$NVRAM" | bb tr '\n' ' '))."
		return 0
	fi
	nvram_is_original "$NVRAM_BACKUP" || fail "the NVRAM backup at $NVRAM_BACKUP is not the vendor's file; not restoring it."
	restore_tmp="$NVRAM.community-restore.$$"
	cp "$NVRAM_BACKUP" "$restore_tmp" || fail "could not copy the original NVRAM."
	if [ "$(file_size "$restore_tmp")" != "$(file_size "$NVRAM_BACKUP")" ] || \
		[ "$(bytes_differing "$NVRAM_BACKUP" "$restore_tmp")" != 0 ]; then
		rm -f "$restore_tmp"
		fail "the copy of the NVRAM backup did not match it; nothing was restored."
	fi
	{ chmod 644 "$restore_tmp" && chown 0:0 "$restore_tmp"; } || { rm -f "$restore_tmp"; fail "could not set restored NVRAM permissions."; }
	mv "$restore_tmp" "$NVRAM" || fail "could not restore the original NVRAM."
	say "vendor's NVRAM restored (ccode $(nvram_ccodes "$NVRAM"))."
}

# What install_patch accepts as hostapd: the vendor's ELF binary, or this patch's wrapper (or
# nothing) with the original saved. Any other script there belongs to someone else's patch.
hostapd_known() {
	if [ ! -e "$HOSTAPD" ] || bb grep -q "$WRAPPER_MARKER" "$HOSTAPD" 2>/dev/null; then
		backup_is_original
	else
		is_elf "$HOSTAPD"
	fi
}

# What nvram_patch accepts: the vendor's CN/0 file, or this region with the vendor's file kept.
nvram_known() {
	nvram_is_original "$NVRAM" ||
		{ nvram_is_original "$NVRAM_BACKUP" && [ "$(nvram_ccodes "$NVRAM")" = "$NVRAM_REGION" ]; }
}

# check_tools stops the script on the first broken applet; a subshell keeps the check going.
tools_work() { ( check_tools ); }
wl_present() { command -v wl >/dev/null 2>&1; }
# The module file is what this unit's Wi-Fi HAL loads; the driver may be unloaded while Wi-Fi is off.
bcmdhd_present() { [ -e /system/lib/modules/bcmdhd.ko ] || [ -d /sys/module/bcmdhd ]; }

# Layer 1: the chip the driver reports. Unknown while bcmdhd is unloaded; another chip fails.
check_chip() {
	info="$(cat "$DRIVER_INFO" 2>/dev/null | bb tr '\n' ' ')"
	echo "WIFI driver_info=[$info]"
	chip="$(echo "$info" | bb awk '{ for (i = 1; i < NF; i++) if ($i == "Chip:") { print $(i + 1); exit } }')"
	if [ -z "$chip" ]; then
		echo "CHECK chip=unknown"
	elif [ "$chip" = "$CHECK_CHIP" ]; then
		echo "CHECK chip=ok"
	else
		echo "CHECK chip=FAIL"
		check_failed=1
	fi
}

# Layer 2: whether the firmware gives the region the patch sets its channel, asked without
# changing the region. No chanspec in the answer (no driver) is unknown, not a refusal.
check_channel() {
	specs="$(wl chanspecs -b 5 -w 20 -c "$NVRAM_REGION" 2>&1 | bb tr '\n' ' ')"
	echo "WIFI chanspecs_$NVRAM_REGION=[$specs]"
	if ! echo "$specs" | bb grep -q '(0x'; then
		echo "CHECK ch36=unknown"
	elif echo " $specs" | bb grep -q " $CHECK_CHANNEL (0x"; then
		echo "CHECK ch36=ok"
	else
		echo "CHECK ch36=FAIL"
		check_failed=1
	fi
}

# Where each fingerprinted file is; while the wrapper is in, hostapd is the saved original.
wifi_file() {
	case "$1" in
		fw_bcmdhd*) echo "/system/vendor/firmware/$1" ;;
		bcmdhd.ko) echo /system/lib/modules/bcmdhd.ko ;;
		hostapd) if bb grep -q "$WRAPPER_MARKER" "$HOSTAPD" 2>/dev/null; then echo "$BACKUP"; else echo "$HOSTAPD"; fi ;;
		netd) echo /system/bin/netd ;;
	esac
}

# Layer 3: the Wi-Fi files against the proven units. A difference never fails the check; the
# USB workflow asks for OH_COOLRAY_FORCE then.
check_fingerprint() {
	fingerprint=ok
	for pair in $KNOWN_WIFI_SIZES; do
		name="${pair%%=*}"; want="${pair#*=}"
		have="$(file_size "$(wifi_file "$name")")"
		echo "FP $name size=${have:-missing} expected=$want"
		[ "$have" = "$want" ] || fingerprint=differs
	done
	echo "CHECK fingerprint=$fingerprint"
}

check_need() {   # $1 name, $2 a function answering yes or no
	if "$2"; then
		echo "CHECK $1=ok"
	else
		echo "CHECK $1=FAIL"
		check_failed=1
	fi
}

# Read-only: what install needs from this unit, one CHECK line each; returns 1 if any is missing
# or the radio is another chip or lacks the channel. The fingerprint line is for the caller.
check_patch() {
	check_failed=0
	check_need root is_root
	check_need busybox_applets tools_work
	check_need wl_tool wl_present
	check_need bcmdhd_driver bcmdhd_present
	check_need hostapd hostapd_known
	check_need nvram nvram_known
	check_chip
	check_channel
	check_fingerprint
	echo "NVRAM $NVRAM: ccode=$(nvram_ccodes "$NVRAM" | bb tr '\n' ' ')regrev=$(nvram_values regrev "$NVRAM" | bb tr '\n' ' ')"
	return "$check_failed"
}

install_patch() {
	channel="$1"
	# Region BY, which the NVRAM is set to below, offers 36-64 and 100-140; 52-140 need
	# radar detection, which this radio lacks, so an access point gets 36-48.
	case "$channel" in
		36|40|44|48) ;;
		*) fail "unsupported 5 GHz channel: $channel" ;;
	esac

	check_tools
	if [ ! -e "$HOSTAPD" ] && [ ! -x "$BACKUP" ]; then
		fail "$HOSTAPD was not found and there is no saved original binary."
	fi
	remount_system_rw
	remove_leftovers
	# While hostapd is the stock binary it is the truth: the backup is taken, or retaken, from it.
	if [ -e "$HOSTAPD" ] && ! bb grep -q "$WRAPPER_MARKER" "$HOSTAPD" 2>/dev/null; then
		if [ ! -e "$BACKUP" ]; then
			if [ -r "$STATE" ]; then
				cp -p "$STATE" "$PREVIOUS_STATE" || fail "could not back up the previous band/channel setting."
			else
				rm -f "$PREVIOUS_STATE"
			fi
		fi
		cp -p "$HOSTAPD" "$BACKUP" || fail "could not save the original hostapd."
		chmod 755 "$BACKUP" || fail "could not set backup permissions."
	fi
	backup_is_original || fail "the saved hostapd at $BACKUP is missing or is not the stock binary."
	nvram_patch

	mkdir -p /data/misc/wifi || fail "could not access /data/misc/wifi."
	state_tmp="$STATE.tmp.$$"
	echo "5 $channel" > "$state_tmp" || fail "could not write band/channel setting."
	chmod 640 "$state_tmp" || fail "could not set setting permissions."
	chown 1000:1010 "$state_tmp" || fail "could not set setting owner."
	# Plain mv: toolbox mv on Android 4.3 takes no options (it read -f as a file name) and is a
	# rename(), which replaces the target; temp and target share a directory, so one filesystem.
	mv "$state_tmp" "$STATE" || fail "could not save band/channel setting."

	# A fresh install tries 5 GHz again, whatever an earlier start left behind. The variant,
	# firmware-default and restart files belong to the 10-29 test build and are only cleared.
	rm -f "$FAILED_FLAG" "$VARIANT_FILE" "$FW_DEFAULTS_FILE" "$ROTATE_FILE"

	# OH Coolray reads the access point's band from here. The wrapper may run as the wifi user,
	# which cannot create files in /data/local/tmp, so the file is made now and given to it.
	if : > "$BAND_MARKER" && chmod 644 "$BAND_MARKER" && chown 1010:1010 "$BAND_MARKER"; then
		say "band marker ready at $BAND_MARKER."
	else
		say "could not prepare $BAND_MARKER; OH Coolray will keep treating the access point as 2.4 GHz."
	fi

	# Rewritten even when already installed, so an older wrapper (one without the band marker) is replaced.
	if [ -e "$HOSTAPD" ] && bb grep -q "$WRAPPER_MARKER" "$HOSTAPD" 2>/dev/null; then
		say "wrapper already installed; replacing it with this version and updating the selected channel."
	fi
	wrapper_tmp="$HOSTAPD.community-tmp.$$"
	write_wrapper "$wrapper_tmp" || fail "could not create wrapper."
	chmod 755 "$wrapper_tmp" || fail "could not set wrapper permissions."
	mv "$wrapper_tmp" "$HOSTAPD" || fail "could not install wrapper."
	say "5 GHz channel $channel selected. The installer will reboot the head unit after the APK install succeeds."
}

rollback_patch() {
	check_tools
	# Without the wrapper nothing keeps the marker true, and a stale one would claim 5 GHz.
	rm -f "$BAND_MARKER" "$FAILED_FLAG" "$VARIANT_FILE" "$FW_DEFAULTS_FILE" "$ROTATE_FILE"
	# The NVRAM first: it is what the radio reads at every load, whatever happens to hostapd.
	if [ -e "$NVRAM_BACKUP" ]; then
		remount_system_rw
		remove_leftovers
		nvram_restore
	fi
	if [ ! -e "$BACKUP" ]; then
		if [ -e "$HOSTAPD" ] && bb grep -q "$WRAPPER_MARKER" "$HOSTAPD" 2>/dev/null; then
			fail "wrapper is installed but its original hostapd backup is missing."
		fi
		if [ -r "$PREVIOUS_STATE" ]; then
			cp -p "$PREVIOUS_STATE" "$STATE" || fail "could not restore the previous band/channel setting."
			rm -f "$PREVIOUS_STATE"
			say "no hostapd binary backup found; restored the previous band/channel setting."
		else
			rm -f "$STATE"
			say "no saved hostapd backup found; removed the patch setting if present."
		fi
		return 0
	fi
	backup_is_original || fail "the saved hostapd at $BACKUP is not the stock binary; not restoring it."
	remount_system_rw
	remove_leftovers
	restore_tmp="$HOSTAPD.community-restore.$$"
	cp "$BACKUP" "$restore_tmp" || fail "could not copy the original hostapd."
	chmod 755 "$restore_tmp" || fail "could not set restored hostapd permissions."
	mv "$restore_tmp" "$HOSTAPD" || fail "could not restore the original hostapd."
	if [ -r "$PREVIOUS_STATE" ]; then
		cp -p "$PREVIOUS_STATE" "$STATE" || fail "could not restore the previous band/channel setting."
		rm -f "$PREVIOUS_STATE"
	else
		rm -f "$STATE" || fail "could not remove the saved band/channel setting."
	fi
	say "original hostapd and previous band/channel setting restored. Reboot the head unit to finish rollback."
}

action="${1:-install}"
case "$action" in
	help|-h|--help)
		usage
		exit 0
		;;
	install)
		[ "$#" -le 2 ] || { usage; exit 2; }
		channel="${2:-36}"
		require_root
		install_patch "$channel"
		;;
	rollback)
		[ "$#" -eq 1 ] || { usage; exit 2; }
		require_root
		rollback_patch
		;;
	check)
		[ "$#" -eq 1 ] || { usage; exit 2; }
		check_patch || exit 1
		;;
	*)
		usage
		exit 2
		;;
esac
