#!/system/bin/sh
export usb="/udisk/single"
chmod +x $usb/done.sh
. $usb/done.sh
