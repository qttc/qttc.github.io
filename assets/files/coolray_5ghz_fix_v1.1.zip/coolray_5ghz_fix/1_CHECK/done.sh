#!/system/bin/sh
# One-shot USB workflow for Android 4.3 Coolray head units. One script serves both kits:
# 1_CHECK ships OH_COOLRAY_CHECK_ONLY and only diagnoses, 2_INSTALL diagnoses and then installs.
# Either way OH_COOLRAY_RESULT.txt on the stick says in plain words what the run found.

hook="b832bc61472727635baffcf25dd28e9f239273e2"
usb=${usb:-/udisk/single}
app_id="com.andrerinas.headunitrevived.coolray"
app_version=121
app_apk="$usb/com.andrerinas.headunitrevived.coolray_4.0.0-alpha-coolray.apk"
helper_id="com.andrerinas.coolrayprogress"
patch_script="$usb/hostapd_5ghz_usb.sh"
status_file="$usb/OH_COOLRAY_STATUS.txt"
result_file="$usb/OH_COOLRAY_RESULT.txt"
wrapper_marker=COMMUNITY_AP_BAND_WRAPPER_V1
install_marker="$usb/OH_COOLRAY_INSTALL_COMMITTED"
rollback_marker="$usb/OH_COOLRAY_ROLLBACK"
channel=36
kit_version="1.1"
# compat_check needs this board and Android release, then asks hostapd_5ghz_usb.sh check about
# the radio: another chip or no channel 36 stops the install for good; Wi-Fi files that differ
# from the proven units stop it until OH_COOLRAY_FORCE is on the stick. The build is reported only.
unit_android="4.3"
unit_board="C3ALFUS"
force_marker="$usb/OH_COOLRAY_FORCE"
# With this file on the stick a run stops after the diagnostics and the compatibility check.
check_only_marker="$usb/OH_COOLRAY_CHECK_ONLY"

[ -d "$usb" ] || exit 1
PATH=/system/bin:/system/xbin
out="$usb/OH_diag2_$(busybox date +%Y%m%d-%H%M%S)-$$"
mkdir -p "$out/snap" "$out/app_logs" "$out/store" || exit 1
exec > "$out/diag.txt" 2>&1
. "$usb/diaglib.sh"

status() {
	line="$(date) $*"
	echo "$line"
	echo "$line" >> "$status_file" 2>/dev/null
}

# A marker counts with or without the .txt a Windows editor adds to an empty file.
has_marker() { [ -f "$1" ] || [ -f "$1.txt" ]; }

patch_state() {
	if bb grep -q "$wrapper_marker" /system/bin/hostapd 2>/dev/null; then echo "установлен"; else echo "не установлен"; fi
}

app_state() {
	installed="$(version_code)"
	if [ -n "$installed" ]; then echo "установлено, versionCode $installed"; else echo "не установлено"; fi
}

# The file a person reads: the verdict first, then why, what the unit is and what to do next.
result() {   # $1 verdict line, $2 what to do next
	{
		echo "$1"
		echo
		if [ -s "$out/compat_reasons.txt" ]; then echo "Что не совпало:"; cat "$out/compat_reasons.txt"; echo; fi
		echo "ГУ: Android $(getprop ro.build.version.release), плата $(getprop ro.product.board), сборка $(getprop ro.build.display.id)"
		[ "$wifi_forced" = 1 ] && echo "Внимание: Wi‑Fi этой ГУ отличается от проверенных; установка разрешена файлом OH_COOLRAY_FORCE."
		echo "Патч 5 ГГц на ГУ сейчас: $(patch_state)"
		echo "Приложение OH Coolray сейчас: $(app_state)"
		echo
		echo "Что дальше: $2"
		echo
		echo "$(date). Пакет coolray_5ghz_fix $kit_version. Подробности для разбора: OH_COOLRAY_STATUS.txt и папка ${out##*/}."
	} > "$result_file" 2>/dev/null
}

version_code() {
	dumpsys package "$app_id" 2>/dev/null | bb awk '
		/versionCode=/ {
			split($0, fields, "versionCode=")
			split(fields[2], value, " ")
			print value[1]
			exit
		}'
}

package_installed() {
	pm path "$1" 2>/dev/null | bb grep -q '^package:'
}

package_info() {
	{
		echo "pm path $app_id"; pm path "$app_id" 2>&1
		echo "package version fields"
		dumpsys package "$app_id" 2>&1 | bb grep -E 'Package \[|versionCode=|versionName=|codePath=|userId='
		echo "pm path $helper_id"; pm path "$helper_id" 2>&1
	} > "$out/package_info.txt"
	copy_app_logs "$out/app_logs"
}

rearm_trigger() {
	if [ ! -e "$usb/$hook" ] && [ -e "$usb/_$hook" ]; then
		mv "$usb/_$hook" "$usb/$hook" || return 1
	fi
	[ -e "$usb/$hook" ]
}

# A check-only run needs neither the APK nor the post-boot capture.
preflight() {
	required_files="$usb/diaglib.sh $patch_script"
	has_marker "$check_only_marker" || required_files="$required_files $usb/capture.sh $app_apk"
	for required in $required_files; do
		if [ ! -r "$required" ]; then
			status "STATE=FAILED reason=missing_file file=${required##*/}"
			result "ИТОГ: НА ФЛЕШКЕ НЕ ХВАТАЕТ ФАЙЛА ${required##*/}. На ГУ ничего не менялось." \
				"очистите флешку и скопируйте в её корень всё содержимое папки заново, затем вставьте флешку снова."
			return 1
		fi
	done
	has_marker "$check_only_marker" || [ -s "$app_apk" ] || { status "STATE=FAILED reason=empty_apk"; return 1; }
	busybox true || { status "STATE=FAILED reason=busybox_missing"; return 1; }
	command -v pm >/dev/null 2>&1 || { status "STATE=FAILED reason=pm_missing"; return 1; }
}

install_app() {
	pm install -r "$app_apk" > "$out/apk_install.txt" 2>&1
	install_rc=$?
	if [ "$install_rc" -ne 0 ] && bb grep -q 'INSTALL_FAILED_UPDATE_INCOMPATIBLE' "$out/apk_install.txt"; then
		status "STATE=APP_SIGNATURE_CONFLICT removing_existing_app_data=1"
		echo "Signature mismatch: uninstalling $app_id will remove its app data." >> "$out/apk_install.txt"
		pm uninstall "$app_id" >> "$out/apk_install.txt" 2>&1 || return 1
		pm install "$app_apk" >> "$out/apk_install.txt" 2>&1 || return 1
		install_rc=0
	fi
	[ "$install_rc" -eq 0 ] || return 1
	bb grep -q '^Success' "$out/apk_install.txt"
}

remove_helper() {
	if ! package_installed "$helper_id"; then
		echo "Notification helper is not installed." > "$out/helper_uninstall.txt"
		return 0
	fi
	pm uninstall "$helper_id" > "$out/helper_uninstall.txt" 2>&1 || return 1
	! package_installed "$helper_id"
}

quick_diagnostics() {
	section "USB update start"
	run date; run uptime; run id; run getprop ro.build.display.id; run getprop ro.build.version.release
	logcat -d -v threadtime -b main -b system > "$out/logcat_before.txt" 2>&1
	logcat -d -v threadtime -b events > "$out/logcat_events_before.txt" 2>&1
	snapshot "before_update"
	softap_layout
	package_info
}

copy_vendor_logs() {
	show /system/bin/c3_kernel_store.sh /system/bin/c3_logcat_store.sh
	copy_vendor_store "$out/store"
}

start_postboot_capture() {
	status "ЭТАП 5/5: сбор контрольных логов после перезагрузки начат, около 20 минут. Настройте OH Coolray по инструкции README_RU.txt из архива; вручную к Wi‑Fi ГУ телефон не подключайте."
	# setsid execs its argument by name, and Android 4.3 has no "true" binary: probe with busybox itself.
	if busybox setsid busybox true 2>/dev/null; then
		(trap '' HUP INT TERM; exec busybox setsid busybox sh "$usb/capture.sh" "$out") \
			< /dev/null > "$out/capture_bg.txt" 2>&1 &
		status "STATE=POSTBOOT_CAPTURE_RUNNING output=${out##*/} pid=$!"
	else
		status "STATE=POSTBOOT_CAPTURE_FOREGROUND output=${out##*/} reason=setsid_unavailable"
		busybox sh "$usb/capture.sh" "$out"
	fi
}

compat_reason() {   # $1 name, $2 found, $3 expected
	case "$1" in
		android) echo "- версия Android: ${2:-не определена}, нужна $3" ;;
		board) echo "- плата ГУ: ${2:-не определена}, нужна $3 (это другая ГУ)" ;;
		root) echo "- скрипт с флешки запущен без прав root" ;;
		busybox_applets) echo "- на ГУ не работают нужные команды BusyBox" ;;
		wl_tool) echo "- нет утилиты Wi‑Fi wl" ;;
		bcmdhd_driver) echo "- нет драйвера Wi‑Fi bcmdhd: модуль Wi‑Fi другой" ;;
		hostapd) echo "- программа точки доступа (hostapd) уже изменена чужим патчем" ;;
		nvram) echo "- файл радио (NVRAM) не заводской и не от этого патча" ;;
		chip) echo "- Wi‑Fi-чип не BCM4339: модуль Wi‑Fi другой" ;;
		ch36) echo "- прошивка Wi‑Fi-чипа не разрешает канал 36 для региона BY: точка 5 ГГц не поднимется" ;;
		*) echo "- проверка Wi‑Fi не выполнилась, см. compat_check.txt" ;;
	esac >> "$out/compat_reasons.txt"
}

compat_note() {   # $1 name, $2 found, $3 expected; a mismatch is a hard one
	echo "COMPAT $1 found=[$2] expected=[$3]" >> "$out/compat_check.txt"
	[ "$2" = "$3" ] && return 0
	compat_miss="$compat_miss $1=$2"
	compat_reason "$1" "$2" "$3"
	compat_hard=1
	return 1
}

wifi_state() {   # $1 CHECK name in wifi_check.txt, $2 text for ok, $3 text otherwise
	line="$(bb grep "^CHECK $1=" "$out/wifi_check.txt" | bb head -n 1)"
	if [ "${line#*=}" = ok ]; then echo "$2"; else echo "$3"; fi
}

# The Wi-Fi files that differ from the proven units, and what the radio checks could see.
wifi_files_reason() {
	{
		echo "- Wi‑Fi-файлы ГУ отличаются от проверенных:"
		bb awk '/^FP / { split($3, h, "="); split($4, w, "="); if (h[2] != w[2]) print $2, h[2], w[2] }' \
			"$out/wifi_check.txt" | while read name have want; do
			[ "$have" = missing ] && have="нет файла" || have="$have байт"
			echo "  $name: $have, у проверенных $want байт"
		done
		echo "- Wi‑Fi-чип: $(wifi_state chip "BCM4339, как у проверенных" "не удалось проверить (драйвер Wi‑Fi не загружен)")"
		echo "- канал 36 для BY: $(wifi_state ch36 "разрешён" "не удалось проверить (драйвер Wi‑Fi не загружен)")"
	} >> "$out/compat_reasons.txt"
}

# The patch script's own read-only check: a FAIL is a hard need, Wi-Fi files other than the
# proven units' a question for the author.
compat_wifi() {
	sh "$patch_script" check > "$out/wifi_check.txt" 2>&1
	wifi_rc=$?
	cat "$out/wifi_check.txt" >> "$out/compat_check.txt"
	failed="$(bb awk '/^CHECK .*=FAIL$/ { sub(/=FAIL$/, "", $2); print $2 }' "$out/wifi_check.txt")"
	[ "$wifi_rc" -eq 0 ] || [ -n "$failed" ] || failed=wifi_check
	if [ -n "$failed" ]; then
		for need in $failed; do compat_reason "$need"; done
		compat_miss="$compat_miss wifi=$(echo $failed | bb tr ' ' ',')"
		compat_hard=1
		return 1
	fi
	bb grep -q '^CHECK fingerprint=ok$' "$out/wifi_check.txt" && return 0
	wifi_files_reason
	compat_miss="$compat_miss wifi_files=differ"
}

# Read-only, after the diagnostics are saved: nothing on the unit changes unless this passes.
compat_check() {
	compat_miss=""; compat_hard=0; wifi_forced=0
	build="$(getprop ro.build.display.id)"
	echo "COMPAT build found=[$build] (reported only)" >> "$out/compat_check.txt"
	compat_note android "$(getprop ro.build.version.release)" "$unit_android"
	compat_note board "$(getprop ro.product.board)" "$unit_board"
	compat_wifi
	[ -z "$compat_miss" ] && return 0
	[ "$compat_hard" = 0 ] && has_marker "$force_marker" || return 1
	echo "COMPAT wifi files differ, let through by ${force_marker##*/}" >> "$out/compat_check.txt"
	status "STATE=COMPAT_WIFI_FORCED$compat_miss build=$build"
	wifi_forced=1
}

# Wi-Fi files that differ are a question for the author; anything else is another unit.
refuse_incompatible() {
	status "STATE=INCOMPATIBLE$compat_miss build=$build; установка не запускалась: Wi‑Fi и приложения не менялись. Подробности в ${out##*/}/compat_check.txt."
	if [ "$compat_hard" = 0 ]; then
		result "ИТОГ: СТАВИТЬ НЕЛЬЗЯ БЕЗ РАЗРЕШЕНИЯ — Wi‑Fi этой ГУ отличается от проверенных. На ГУ ничего не менялось." \
			"пришлите автору этот файл, OH_COOLRAY_STATUS.txt и папку ${out##*/}. Если он подтвердит, на шаге 2 положите рядом с файлами из папки 2_INSTALL пустой файл OH_COOLRAY_FORCE."
	else
		result "ИТОГ: СТАВИТЬ НЕЛЬЗЯ — эта ГУ не подходит. На ГУ ничего не менялось." \
			"не ставьте. Если хотите разобраться, пришлите автору этот файл, OH_COOLRAY_STATUS.txt и папку ${out##*/}."
	fi
	sync
	exit 1
}

report_check_only() {
	status "STATE=CHECK_ONLY_OK; ГУ подходит, установка не запускалась (на флешке лежит ${check_only_marker##*/})."
	result "ИТОГ: МОЖНО СТАВИТЬ — ГУ подходит. На ГУ ничего не менялось." \
		"шаг 2 из README_RU.txt: очистите флешку, скопируйте в её корень всё из папки 2_INSTALL и вставьте флешку в ГУ."
	sync
	exit 0
}

rollback_wifi() {
	sh "$patch_script" rollback > "$out/hostapd_rollback.txt" 2>&1
	return $?
}

# The USB autorun hook is one-shot. Keep the folder disabled during this run.
if [ -e "$usb/$hook" ]; then
	mv "$usb/$hook" "$usb/_$hook" 2>/dev/null
fi
sync
status "STATE=RUN_STARTED kit=$kit_version output=${out##*/}"

[ -f "$rollback_marker.txt" ] && [ ! -f "$rollback_marker" ] && mv "$rollback_marker.txt" "$rollback_marker"
if [ -f "$rollback_marker" ]; then
	status "ОТКАТ: восстанавливаю исходный hostapd и предыдущее состояние Wi‑Fi. APK не сохранялся и не откатывается автоматически."
	if mv "$rollback_marker" "$rollback_marker.processing" 2>/dev/null; then
		sh "$patch_script" rollback > "$out/hostapd_rollback.txt" 2>&1
		rollback_rc=$?
		if [ "$rollback_rc" -eq 0 ]; then
			rm -f "$rollback_marker.processing"
			status "STATE=WIFI_ROLLBACK_OK; Android перезагрузится для применения исходной настройки."
			result "ИТОГ: ОТКАТ ВЫПОЛНЕН — заводской Wi‑Fi возвращён, ГУ перезагружается." \
				"ничего. Приложение OH Coolray осталось на ГУ; удалять его не обязательно."
			sync; sleep 3; reboot
		else
			mv "$rollback_marker.processing" "$rollback_marker" 2>/dev/null
			status "STATE=WIFI_ROLLBACK_FAILED exit=$rollback_rc; сохраните диагностику и статус."
			result "ИТОГ: ОТКАТ НЕ УДАЛСЯ." "пришлите автору этот файл, OH_COOLRAY_STATUS.txt, hostapd_5ghz_patch.log и папку ${out##*/}."
		fi
	else
		status "STATE=WIFI_ROLLBACK_FAILED reason=could_not_lock_rollback_request"
	fi
	exit 0
fi

if ! preflight; then exit 1; fi
quick_diagnostics
copy_vendor_logs
kernel_wifi_report

# After the automatic reboot, the same USB hook starts only the verification capture; a
# check-only run never installed anything, so it ignores a marker left on a reused stick.
if [ -f "$install_marker" ] && ! has_marker "$check_only_marker"; then
	if [ "$(version_code)" != "$app_version" ]; then
		status "STATE=CHECK_REQUIRED reason=app_version_mismatch expected=$app_version actual=$(version_code)"
	fi
	package_info
	start_postboot_capture
	exit 0
fi

status "ЭТАП 1/5: короткая исходная диагностика сохранена в ${out##*/}. Проверяю ГУ и её Wi‑Fi: чип, канал 36 и файлы Wi‑Fi; пока ничего не менялось."
compat_check || refuse_incompatible
status "STATE=COMPAT_OK android=$unit_android board=$unit_board build=$build wifi_forced=$wifi_forced"
has_marker "$check_only_marker" && report_check_only
# Replaced by the outcome below; still here after a boot means the install was cut short.
result "ИТОГ: УСТАНОВКА НЕ ЗАВЕРШИЛАСЬ — ГУ подходит, установка началась, но не дошла до конца (например, ГУ выключилась)." \
	"пришлите автору этот файл, OH_COOLRAY_STATUS.txt, hostapd_5ghz_patch.log и папку ${out##*/}."
status "ЭТАП 2/5: настраиваю SoftAP 5 ГГц, канал $channel; сначала выполняется обратимый Wi‑Fi-патч."
sh "$patch_script" install "$channel" > "$out/hostapd_install.txt" 2>&1
patch_rc=$?
if [ "$patch_rc" -ne 0 ]; then
	rollback_wifi
	rollback_rc=$?
	status "STATE=FAILED reason=wifi_patch_failed exit=$patch_rc rollback_exit=$rollback_rc; APK не устанавливался."
	if [ "$rollback_rc" -eq 0 ]; then
		result "ИТОГ: УСТАНОВКА НЕ УДАЛАСЬ — патч Wi‑Fi не встал и сам откатился, ГУ как была. Приложение не ставилось." \
			"пришлите автору этот файл, OH_COOLRAY_STATUS.txt, hostapd_5ghz_patch.log и папку ${out##*/}."
	else
		result "ИТОГ: УСТАНОВКА НЕ УДАЛАСЬ, И ОТКАТ ТОЖЕ — Wi‑Fi ГУ может не работать. Приложение не ставилось." \
			"сразу пришлите автору этот файл, OH_COOLRAY_STATUS.txt, hostapd_5ghz_patch.log и папку ${out##*/}."
	fi
	sync
	exit 1
fi

status "ЭТАП 3/5: устанавливаю OH Coolray versionCode=$app_version. Если Android потребует удалить несовместимую подпись, данные приложения будут сброшены."
# 5 GHz stays on until the drops are debugged: an APK that did not install keeps the Wi-Fi patch.
if ! install_app; then
	status "STATE=FAILED reason=app_install_failed wifi_patch_kept=1; Wi‑Fi 5 ГГц оставлен и заработает после перезапуска ГУ. Установите APK вручную или повторите установку с флешки."
	result "ИТОГ: УСТАНОВЛЕНО ЧАСТИЧНО — Wi‑Fi 5 ГГц включён, а приложение OH Coolray не установилось." \
		"повторите шаг 2 ещё раз. Если не поможет, пришлите автору этот файл, OH_COOLRAY_STATUS.txt и папку ${out##*/}."
	sync
	exit 1
fi
# Android accepted the APK; a versionCode other than app_version is reported, not rolled back.
installed_version="$(version_code)"
if [ "$installed_version" = "$app_version" ]; then
	status "STATE=APP_INSTALL_OK app=$app_id versionCode=$app_version"
else
	status "STATE=CHECK_REQUIRED reason=app_version_mismatch expected=$app_version actual=$installed_version; Android принял APK, установка продолжается."
fi

status "ЭТАП 4/5: удаляю старое приложение-помощник уведомлений."
if remove_helper; then
	status "STATE=HELPER_REMOVED package=$helper_id"
else
	status "STATE=WARNING helper_uninstall_failed package=$helper_id; после загрузки итог будет CHECK_REQUIRED."
fi

echo "installed $app_id versionCode=$app_version channel=$channel" > "$install_marker" || {
	status "STATE=FAILED reason=install_marker_write_failed; Wi‑Fi и APK уже обновлены, перезагрузите ГУ вручную."
	exit 1
}
if rearm_trigger; then
	status "STATE=POSTBOOT_TRIGGER_ARMED"
else
	status "STATE=WARNING postboot_trigger_not_rearmed; после загрузки извлеките и снова вставьте флешку один раз."
fi
status "ЭТАП 4/5: Wi‑Fi-патч и APK установлены. ГУ сейчас перезагрузится автоматически; после запуска настройте OH Coolray по инструкции README_RU.txt из архива."
result "ИТОГ: УСТАНОВЛЕНО — патч Wi‑Fi 5 ГГц и приложение OH Coolray. ГУ перезагрузилась сама." \
	"шаг 3 из README_RU.txt: один раз настройте OH Coolray."
status "ЭТАП 5/5: после загрузки начнётся контрольный сбор на 20 минут; откройте этот файл после завершения, чтобы увидеть результат."
sync
sleep 3
reboot
reboot_rc=$?
status "STATE=REBOOT_COMMAND_RETURNED exit=$reboot_rc; если ГУ не перезапустилось, перезагрузите его вручную."
sync
