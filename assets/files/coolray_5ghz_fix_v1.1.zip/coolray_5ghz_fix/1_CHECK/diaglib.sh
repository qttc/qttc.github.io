#!/system/bin/sh
#--------------------------------------------------------------------------------#
# OH Coolray read-only diagnostics v2: shared functions. Sourced by done.sh (the hook's
# foreground part, mksh) and capture.sh (the background capture, busybox sh), so POSIX sh
# only. Nothing here changes the unit: every command only reads, and every write goes to
# the USB stick under $out.
#--------------------------------------------------------------------------------#

secrets='psk|passphrase|password|wep_key|auth_key|sae_|private_key|identity|ca_cert|client_cert'
wifidir=/data/misc/wifi
hostapd_ctrl=/data/misc/wifi/hostapd
# bcmdhd.ko has this path compiled in (its nvram_path parameter is empty) and downloads the
# file, with the region it names, on every driver load.
nvram_default=/system/etc/wifi/bcmdhd.cal

# busybox is on this unit (the Community pack relies on it); toolbox lacks awk, od, tr, strings.
bb() { busybox "$@"; }

mask() { bb grep -v -i -E "$secrets"; }

section() { sync; echo; echo "===== $1 ====="; }

run() { echo "--- \$ $*"; "$@" 2>&1; }

show() {
	for f in "$@"; do
		echo "--- $f"
		if [ -e "$f" ]; then cat "$f" 2>&1; else echo "(absent)"; fi
	done
}

show_masked() {
	for f in "$@"; do
		echo "--- $f (secret lines removed)"
		if [ -e "$f" ]; then cat "$f" 2>&1 | mask; else echo "(absent)"; fi
	done
}

copy_out() { cat "$1" > "$2/${1##*/}" 2>/dev/null && echo "copied $1"; }

# The OH Coolray log folder, wherever this unit mounts the internal storage.
app_log_dir() {
	for d in /sdcard/Download/OpenHeadunitLogs.coolray /storage/sdcard0/Download/OpenHeadunitLogs.coolray \
	         /mnt/sdcard/Download/OpenHeadunitLogs.coolray /storage/emulated/legacy/Download/OpenHeadunitLogs.coolray; do
		[ -d "$d" ] && { echo "$d"; return; }
	done
}

copy_app_logs() {   # $1 target dir
	mkdir -p "$1"
	d=$(app_log_dir)
	[ -n "$d" ] || { echo "no OH Coolray log folder found"; return; }
	for f in "$d"/*; do [ -f "$f" ] && copy_out "$f" "$1"; done
}

# One line saying where the access point stands, from reads and wl's get commands only.
ap_state_line() {
	echo "operstate=$(cat /sys/class/net/wlan0/operstate 2>/dev/null) carrier=$(cat /sys/class/net/wlan0/carrier 2>/dev/null)" \
	     "hostapd=$(ps | bb grep -c '[h]ostapd') dnsmasq=$(ps | bb grep -c '[d]nsmasq') supplicant=$(ps | bb grep -c '[w]pa_supplicant')" \
	     "fw=$(cat /sys/module/bcmdhd/parameters/firmware_path 2>/dev/null)" \
	     "hostapd_sta=$(hostapd_cli -p "$hostapd_ctrl" -i wlan0 all_sta 2>/dev/null | bb grep -c -E '^[0-9a-fA-F:]{17}$')" \
	     "wl_isup=$(wl isup 2>&1 | bb tr '\n' ' ') wl_ap=$(wl ap 2>&1 | bb tr '\n' ' ') wl_chanspec=$(wl chanspec 2>&1 | bb tr '\n' ' ')" \
	     "wl_country=$(wl country 2>&1 | bb tr '\n' ' ')"
}

# Everything the attempt leaves behind, into $out/snap/<time>_<label>.txt: wl's get
# commands, hostapd_cli's status queries, the generated hostapd.conf with its secret lines
# removed, the DHCP and tethering state, and the system log lines about the radio.
snapshot() {   # $1 label
	f="$out/snap/$(date +%H%M%S)_$1.txt"
	{
		echo "== $1 $(date) | $(uptime)"
		echo "-- summary"; ap_state_line
		echo "-- wlan0 sysfs"
		for k in operstate carrier flags address statistics/tx_packets statistics/rx_packets statistics/tx_errors; do
			echo "$k=$(cat /sys/class/net/wlan0/$k 2>&1)"
		done
		echo "firmware_path=$(cat /sys/module/bcmdhd/parameters/firmware_path 2>&1)"
		echo "-- processes"; ps | bb grep -E 'hostapd|dnsmasq|wpa_supplicant|netd|^USER'
		echo "-- wl (read-only queries)"
		for q in ver isup ap apsta ssid bssid chanspec channel status maxassoc bss_maxassoc assoclist band bands country cap btc_mode PM mpc; do
			echo "wl $q: $(wl $q 2>&1 | bb tr '\n' ' ')"
		done
		echo "-- wl chanspecs"; wl chanspecs 2>&1 | bb tr '\n' ' '; echo
		# Whether the firmware calls the 5 GHz channel passive or radar, which bars an AP there.
		for c in 36 40 44 48 149 153 157 161 165; do echo "wl chan_info $c: $(wl chan_info $c 2>&1 | bb tr '\n' ' ')"; done
		for c in status get_config all_sta; do
			echo "-- hostapd_cli $c"; hostapd_cli -p "$hostapd_ctrl" -i wlan0 $c 2>&1 | mask
		done
		show_masked "$wifidir/hostapd.conf"
		echo "-- 5 GHz wrapper state and the band marker OH Coolray reads"
		run ls -ld /data/local/tmp
		run ls -l /data/local/tmp/oh_hostapd_band
		show /data/local/tmp/oh_hostapd_band "$wifidir/community_ap_band" "$wifidir/community_ap_band.failed" \
			"$wifidir/community_ap_band.log" "$wifidir/community_ap_status.txt"
		run ls -la "$wifidir" /data/misc/dhcp
		show /data/misc/dhcp/dnsmasq.leases
		run netcfg
		show /proc/net/dev /proc/net/arp
		run iptables -t nat -L -n
		echo "-- getprop (wifi/dhcp/ap)"; getprop | bb grep -i -E 'wifi|wlan|dhcp|hostapd|dnsmasq|tether|softap|hotspot'
		echo "-- tether (dumpsys connectivity)"; dumpsys connectivity 2>&1 | bb grep -i -A 4 'tether'
		echo "-- system log, radio lines"
		logcat -d -v threadtime -b main -b system 2>&1 | bb grep -i -E 'softap|hostapd|wifistatemachine|wificontroller|wifiservice|tether|netd|dnsmasq|wifihw|wifi_hal|bcmdhd|dhd|wifi_country|setcountry|driver country' | bb tail -n 150
	} > "$f" 2>&1
	sync
}

# The stored access point configuration by layout: Neusoft's softap.conf is 4 bytes longer
# than AOSP's. The SSID is printed only when it equals the one hostapd.conf names, the
# passphrase never, only its length, and extra bytes only where the layout proves they are
# no part of a string.
softap_layout() {
	f="$wifidir/softap.conf"
	[ -f "$f" ] || { echo "softap.conf absent"; return; }
	echo "size=$(bb wc -c < "$f" | bb tr -d ' ') bytes (AOSP 4.3 layout: int version, UTF ssid, int authType, UTF psk)"
	want=$(bb grep '^ssid=' "$wifidir/hostapd.conf" 2>/dev/null | bb cut -d= -f2)
	bb od -An -v -t u1 "$f" | bb awk -v want="$want" '
		{ for (i = 1; i <= NF; i++) b[n++] = $i }
		function be16(p) { return b[p] * 256 + b[p+1] }
		function be32(p) { return ((b[p] * 256 + b[p+1]) * 256 + b[p+2]) * 256 + b[p+3] }
		function hex4(p) { return sprintf("%02x %02x %02x %02x", b[p], b[p+1], b[p+2], b[p+3]) }
		END {
			if (n < 8) { print "too short to parse"; exit }
			print "version=" be32(0)
			l = be16(4); p = 6 + l
			if (p + 4 > n) { print "first string runs past the end, layout unknown"; exit }
			s = ""; for (i = 6; i < p; i++) s = s sprintf("%c", b[i] + 0)
			if (s == want) print "ssid=\"" s "\" (" l " bytes, same as hostapd.conf)"
			else print "first string: " l " bytes, not the hostapd ssid, not printed"
			print "authType=" be32(p); p += 4
			la = be16(p); lb = be16(p + 4)
			a = (p + 2 + la + 4 == n); c = (p + 4 + 2 + lb == n)
			if (a && !c) { print "psk: " la " bytes (hidden)"; print "trailing int=" be32(n - 4) " bytes=" hex4(n - 4) }
			else if (c && !a) { print "int after authType=" be32(p) " bytes=" hex4(p); print "psk: " lb " bytes (hidden)" }
			else if (p + 2 + la == n) print "psk: " la " bytes (hidden); AOSP layout, no extra bytes"
			else print (n - p) " bytes after authType, layout unknown, not printed"
		}'
}

# Where the unit's own log keepers write, read from their scripts; directories only.
vendor_store_dirs() {
	cat /system/bin/c3_kernel_store.sh /system/bin/c3_logcat_store.sh 2>/dev/null |
		bb grep -o -E '/(data|sdcard|cache|storage|mnt)/[A-Za-z0-9_./-]+' | bb sort -u |
		while read p; do
			if [ -d "$p" ]; then echo "$p"; elif [ -d "${p%/*}" ]; then echo "${p%/*}"; fi
		done
	[ -d /sdcard/xsf/log ] && echo /sdcard/xsf/log
}

# Appends one block to $out/link.txt: how the radio and each joined station are doing.
# Read-only wl queries; one this unit's wl lacks only leaves its error text in the file.
link_stats() {
	{
		echo "== $(date +%H:%M:%S) uptime=$(cat /proc/uptime 2>&1) load=$(cat /proc/loadavg 2>&1)"
		echo "wl assoclist: $(wl assoclist 2>&1 | bb tr '\n' ' ')"
		for sta in $(wl assoclist 2>/dev/null | bb awk '{ print $NF }'); do
			echo "-- wl sta_info $sta"; wl sta_info "$sta" 2>&1
		done
		echo "-- wl counters"; wl counters 2>&1
		echo "-- wl chanim_stats"; wl chanim_stats 2>&1
		echo "-- tcp"; bb grep -E '^(Tcp|TcpExt):' /proc/net/snmp /proc/net/netstat 2>&1
	} >> "$out/link.txt" 2>&1
}

# The wider state of the unit at the start and the end of a capture, into $out/extended_$1.txt.
extended_report() {   # $1 label
	{
		echo "== $1 $(date)"
		echo "-- top"; top -n 1 -m 12 2>&1
		echo "-- /proc/meminfo"; cat /proc/meminfo 2>&1
		echo "-- dumpsys wifi"; dumpsys wifi 2>&1 | mask
		echo "-- dumpsys bluetooth_manager"; dumpsys bluetooth_manager 2>&1 | mask
		echo "-- getprop"; getprop 2>&1 | mask
		echo "-- logcat radio buffer"; logcat -d -v threadtime -b radio 2>&1 | bb tail -n 300
	} > "$out/extended_$1.txt" 2>&1
	sync
}

# Read-only: the kernel's 802.11 stack and the Broadcom driver as this unit has them, into
# $out/kernel/ for offline reading. Uses only cat, ls, cp, wl and busybox grep/tr/tail.
kernel_wifi_report() {
	k="$out/kernel"
	mkdir -p "$k"
	{
		echo "== /proc/version"; cat /proc/version 2>&1
		echo "== /proc/modules"; cat /proc/modules 2>&1
		for m in cfg80211 compat bcmdhd dhd; do
			[ -d "/sys/module/$m/parameters" ] || continue
			echo "== /sys/module/$m/parameters"
			for p in /sys/module/$m/parameters/*; do echo "${p##*/}=$(cat "$p" 2>&1)"; done
		done
		echo "== module and firmware files"
		ls -la /system/lib/modules /system/vendor/lib/modules /lib/modules /system/vendor/firmware /system/etc/wifi 2>&1
		echo "== wl band (a band lock bars 5 GHz) and what the firmware says about channels 36-48 and 149-165"
		echo "wl band: $(wl band 2>&1 | bb tr '\n' ' ')"
		for c in 36 40 44 48 149 153 157 161 165; do echo "wl chan_info $c: $(wl chan_info $c 2>&1 | bb tr '\n' ' ')"; done
		echo "== kernel log lines about regulatory, cfg80211 and the driver"
		for f in "$out"/store/*; do
			[ -f "$f" ] && bb grep -a -i -E 'regulat|regdom|world|cfg80211|compat|ccode|country|dhd|wl_cfg|chanspec|Firmware up' "$f"
		done | bb tail -n 300
	} > "$k/report.txt" 2>&1
	region_report
	for f in /system/lib/modules/*.ko /system/vendor/lib/modules/*.ko /lib/modules/*.ko \
		/system/vendor/firmware/*nvram* /system/etc/wifi/*nvram* /system/etc/firmware/*nvram*; do
		[ -f "$f" ] && cp "$f" "$k/" 2>/dev/null
	done
	nvram="$(cat /sys/module/bcmdhd/parameters/nvram_path 2>/dev/null)"
	[ -n "$nvram" ] && [ -f "$nvram" ] && cp "$nvram" "$k/" 2>/dev/null
	# A proc file reports size 0, so it is read through, not copied.
	[ -f /proc/config.gz ] && cat /proc/config.gz > "$k/config.gz" 2>/dev/null
	sync
}

# The firmware's side of the region: what it runs now, the locales it carries and the NVRAM
# that picks its default. Read-only wl get queries; an unknown one leaves its error text.
region_firmware() {
	for q in "country" "country list" "country list a" "country list b" "autocountry_default" \
		"nvram_get ccode" "nvram_get regrev" "revinfo" "spect" "radar" "dfs_status" "curpower" \
		"nmode" "nreqd" "mimo_bw_cap" "bw_cap 2g" "bw_cap 5g" "macmode" "mac"; do
		# $q stays unquoted: "country list a" is three arguments.
		echo "-- wl $q"; wl $q 2>&1
	done
	# Per band and width, the chanspecs the region allows: no 40 MHz and nmode 0 marked BY/0.
	for b in 2 5; do
		for w in 20 40 80; do
			[ "$b$w" = 280 ] && continue
			echo "-- wl chanspecs -b $b -w $w"; wl chanspecs -b $b -w $w 2>&1 | bb tr '\n' ' '; echo
		done
	done
	echo "-- wl chan_info, every 5 GHz channel"; chan_info_5g
	echo "-- NVRAM files (the 5 GHz installer keeps the vendor's as .community-stock)"; ls -l "$nvram_default"* 2>&1
	echo "-- $nvram_default.community-stock: ccode/regrev"; bb grep -a -n -E '^(ccode|regrev)=' "$nvram_default.community-stock" 2>&1
	echo "-- $nvram_default: region and board lines (the whole file is in files/)"
	bb grep -a -n -i -E '^(ccode|regrev|cc|country|devid|boardtype|boardrev|sromrev|aa2g|aa5g|subband5gver)=' "$nvram_default" 2>&1
	echo "-- wl nvram_dump (the NVRAM as the firmware holds it)"; wl nvram_dump 2>&1
	echo "-- wl otpdump (the module's one-time memory, where a default region can also sit)"; wl otpdump 2>&1
}

chan_info_5g() {
	for c in 36 40 44 48 52 56 60 64 100 104 108 112 116 120 124 128 132 136 140 144 149 153 157 161 165; do
		echo "wl chan_info $c: $(wl chan_info $c 2>&1 | bb tr '\n' ' ')"
	done
}

# For every locale the firmware carries, the 5 GHz chanspecs it allows. -c only names the
# country to ask about; the radio's own country stays as it is.
locale_channels() {
	for c in $(wl country list 2>/dev/null | bb awk 'length($1) == 2 && $1 ~ /^[A-Z0-9]+$/ { print $1 }'); do
		echo "$c 20MHz: $(wl chanspecs -b 5 -w 20 -c "$c" 2>&1 | bb tr '\n' ' ')"
		echo "$c 40MHz: $(wl chanspecs -b 5 -w 40 -c "$c" 2>&1 | bb tr '\n' ' ')"
	done
}

# The Android side: whatever could send the driver a COUNTRY command, and how init loads it.
region_android() {
	echo "-- getprop (country, locale, region)"; getprop 2>&1 | bb grep -i -E 'country|locale|region'
	for db in /data/data/com.android.providers.settings/databases/settings.db*; do
		echo "-- $db"; bb strings "$db" 2>&1 | bb grep -i -E 'wifi|country' | bb sort -u
	done
	for f in /system/etc/wifi/*.conf "$wifidir/wpa_supplicant.conf" "$wifidir/p2p_supplicant.conf" "$wifidir/hostapd.conf"; do
		echo "-- $f (country and driver lines)"; bb grep -i -E '^(country|driver_param|p2p_oper|p2p_listen)' "$f" 2>&1 | mask
	done
	echo "-- init scripts: Wi-Fi driver and daemons"
	bb grep -n -i -E 'bcmdhd|insmod|rmmod|wlan|wifi|hostapd|supplicant|country' /init*.rc 2>&1
}

# The board's side: bcmdhd turns a COUNTRY into a locale through the kernel's wifi platform
# data (get_country_code), which lives in the kernel image, not the module. Its function
# names are in /proc/kallsyms (copied whole as kallsyms.txt); module symbols carry a
# [module] tag and are counted apart.
region_kernel() {
	echo "-- kptr_restrict=$(cat /proc/sys/kernel/kptr_restrict 2>&1) (addresses may read as zeros; names still show)"
	echo "-- /proc/cmdline"; cat /proc/cmdline 2>&1
	echo "-- kernel symbols naming a country, a regulatory domain or the wifi platform glue"
	bb grep -i -E 'country|regdom|regulatory|wifi|wlan|bcmdhd|brcm|bcm43|sdhci_.*card' /proc/kallsyms 2>&1 | bb grep -v '\['
	echo "-- module symbols naming a country: $(bb grep -i 'country' /proc/kallsyms 2>/dev/null | bb grep -c '\[')"
	echo "-- iw (cfg80211's own view of the channels)"
	if command -v iw >/dev/null 2>&1; then iw reg get 2>&1; iw list 2>&1; else echo "iw is not on this unit"; fi
}

# Unchanged copies to read offline: firmware and NVRAM, the Wi-Fi HAL, the daemons that could
# send COUNTRY, the framework that would, and the init and fstab files. Lists what it copied.
copy_radio_files() {   # $1 target dir
	mkdir -p "$1"
	hb=/system/bin/hostapd; [ -x /system/bin/hostapd.community-stock ] && hb=/system/bin/hostapd.community-stock
	for f in /system/vendor/firmware/fw_bcmdhd*.bin /system/etc/wifi/* /system/lib/libhardware_legacy.so \
		/system/bin/wpa_supplicant "$hb" /system/bin/netd /system/framework/framework.odex \
		/system/framework/services.odex /fstab.* /init*.rc /ueventd*.rc; do
		[ -f "$f" ] && cp "$f" "$1/" 2>/dev/null
	done
	ls -l "$1"
}

# The boot partition fstab names, or its by-name link.
boot_partition() {
	dev=$(bb awk '$2 == "/boot" { print $1; exit }' /fstab.* 2>/dev/null)
	[ -n "$dev" ] || dev=$(ls /dev/block/platform/*/by-name/boot 2>/dev/null)
	echo "$dev"
}

# The kernel image holds the board's get_country_code; the boot partition is read, never
# written, and copied only when /sys gives it a size up to 64 MB.
copy_boot_image() {   # $1 target dir
	echo "-- /proc/partitions"; cat /proc/partitions 2>&1
	echo "-- by-name links"; ls -l /dev/block/platform/*/by-name 2>&1
	dev=$(boot_partition)
	[ -n "$dev" ] || { echo "boot partition not found"; return; }
	name=$(ls -l "$dev" 2>/dev/null | bb awk '{ print $NF }'); name=${name##*/}
	sectors=$(cat "/sys/class/block/$name/size" 2>/dev/null)
	echo "boot partition $dev ($name), ${sectors:-unknown} sectors of 512 bytes"
	if [ "${sectors:-0}" -gt 0 ] && [ "$sectors" -le 131072 ]; then
		cat "$dev" > "$1/boot.img" 2>&1 && echo "copied to files/boot.img"
	else
		echo "size unknown or over 64 MB; not copied"
	fi
}

# Where the radio's region comes from: region.txt, locales.txt, the whole kallsyms and the
# files above, all under $out/kernel.
region_report() {
	k="$out/kernel"
	{ echo "== firmware"; region_firmware; echo "== kernel"; region_kernel; echo "== android"; region_android; } \
		> "$k/region.txt" 2>&1
	locale_channels > "$k/locales.txt" 2>&1
	cat /proc/kallsyms > "$k/kallsyms.txt" 2>/dev/null
	{ copy_radio_files "$k/files"; copy_boot_image "$k/files"; } > "$k/files.txt" 2>&1
	sync
}

# The vendor stores' recent files into $1. dmesg reads empty on this unit because
# c3_kernel_store drains it every 3 s, so its file is the only kernel log there is. That
# file reached 1.8 MB in one drive, so the cap sits far above it.
copy_vendor_store() {
	mkdir -p "$1"
	vendor_store_dirs | while read d; do
		[ -n "$d" ] || continue
		bb find "$d" -maxdepth 1 -type f -mmin -180 -size -40000k \
			-exec cp {} "$1/" \; 2>/dev/null
	done
}

strs() { bb strings "$@" 2>/dev/null || bb grep -a -o -E '[[:print:]]{4,}' "$@" 2>/dev/null; }

# Who could hand the driver a region: the Wi-Fi HAL (which module it loads, with what
# arguments), the daemons that carry bcmdhd's private commands, and any framework or app
# code naming a Wi-Fi country. Part of strings_report; nothing is cut short.
strings_region() {
	echo "== libhardware_legacy.so (driver module, firmware and country)"
	strs /system/lib/libhardware_legacy.so | bb grep -i -E '\.ko|bcmdhd|nvram|fw_|firmware_path|driver|country|module' | bb sort -u
	sb=/system/bin/hostapd; [ -x /system/bin/hostapd.community-stock ] && sb=/system/bin/hostapd.community-stock
	for b in /system/bin/wpa_supplicant "$sb" /system/bin/netd; do
		echo "== $b (country and private driver commands)"
		strs "$b" | bb grep -i -E 'country|priv_lib|bcmdhd|DRIVER |\.ko' | bb sort -u
	done
	echo "== framework and app code naming a Wi-Fi country"
	for f2 in /system/framework/*.odex /system/app/*.odex /system/priv-app/*.odex; do
		[ -f "$f2" ] || continue
		hits=$(strs "$f2" | bb grep -E 'setCountryCode|wifi_country_code|wificountrycode|DRIVER COUNTRY|COUNTRY ' | bb sort -u)
		[ -n "$hits" ] && { echo "-- $f2"; echo "$hits"; }
	done
}

# What the binaries say, read-only: how netd writes hostapd.conf (channel, hw_mode,
# max_num_sta), whether this hostapd knows 5 GHz (hw_mode=a, 11ac) and what the framework
# and the unit's own settings app call the access point fields. Slow on this CPU, so it runs
# in the background next to the watch.
strings_report() {
	f="$out/strings.txt"
	{
		echo "== netd"; strs /system/bin/netd | bb grep -i -E 'softap|hostapd|max_num_sta|max_sta|maxsta|channel=|hw_mode|ieee80211|wpa_passphrase|ctrl_interface|fw_bcmdhd|firmware_path|apsta|dnsmasq|tether'
		# The real binary, not the 5 GHz wrapper that may have taken its name.
		hb=/system/bin/hostapd; [ -x /system/bin/hostapd.community-stock ] && hb=/system/bin/hostapd.community-stock
		echo "== hostapd -v ($hb)"; "$hb" -v 2>&1 | bb head -n 5
		echo "== hostapd ($hb)"; strs "$hb" | bb grep -i -E 'max_num_sta|hw_mode|ieee80211ac|ieee80211n|vht|ht_capab|country_code|^channel|nl80211|driver|CONFIG_' | bb sort -u | bb head -n 120
		for f2 in /system/framework/framework.odex /system/framework/framework.jar /system/framework/services.odex /system/framework/services.jar /system/framework/framework2.odex; do
			[ -f "$f2" ] || continue
			echo "== $f2"; strs "$f2" | bb grep -i -E 'max_num_sta|maxnumsta|maxsta|max_sta|numsta|maxclient|max_client|apmax|softap set|softap |ap_max|wifiap|hotspot' | bb sort -u | bb head -n 80
		done
		for a in /system/app/KC2_Setting /system/app/Settings /system/app/nFore_Hades; do
			[ -f "$a.odex" ] && { echo "== $a.odex"; strs "$a.odex" | bb grep -i -E 'hotspot|softap|wifiap|max_?sta|tether|5g|band' | bb sort -u | bb head -n 80; }
			[ -f "$a.apk" ] && { echo "== $a.apk classes.dex"; bb unzip -p "$a.apk" classes.dex 2>/dev/null | strs | bb grep -i -E 'hotspot|softap|wifiap|max_?sta|tether|5g|band' | bb sort -u | bb head -n 80; }
		done
		echo "== fw_bcmdhd_apsta.bin"; strs /system/vendor/firmware/fw_bcmdhd_apsta.bin | bb grep -i -E 'version|wl0:' | bb head -n 10
		strings_region
		echo "== done $(date)"
	} > "$f" 2>&1
	sync
}
