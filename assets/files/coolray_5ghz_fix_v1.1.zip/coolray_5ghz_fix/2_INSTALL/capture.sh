#!/system/bin/sh
#--------------------------------------------------------------------------------#
# Post-reboot diagnostic capture for the Coolray USB update. Runs on Android 4.3 with
# BusyBox applets and POSIX shell syntax. Reads the head unit and writes to the USB stick.
#
# timeline.txt gets one line per minute and one per change of the access point's state
# (hostapd appearing or dying, the radio entering AP mode, the firmware switching), each
# change with a full snapshot in snap/. strings.txt is read from the binaries meanwhile.
#--------------------------------------------------------------------------------#

out="$1"
[ -d "$out" ] || exit 1
usb=${out%/*}
. "$usb/diaglib.sh"

duration=${CAPTURE_SECONDS:-1200}
poll=${POLL_SECONDS:-5}
heartbeat=${HEARTBEAT_POLLS:-12}   # polls between heartbeat lines: 12 x 5 s = 1 min
max_log=20000000

timeline="$out/timeline.txt"
status_file="$usb/OH_COOLRAY_STATUS.txt"
app_id="com.andrerinas.headunitrevived.coolray"
helper_id="com.andrerinas.coolrayprogress"
app_version=121
channel=36
hook="b832bc61472727635baffcf25dd28e9f239273e2"
echo "$(date +%H:%M:%S) capture started for ${duration}s, pid $$" >> "$timeline"

logcat -v threadtime -b main -b system > "$out/logcat_live.txt" 2>&1 &
lc=$!

(strings_report; echo done > "$out/strings_report.done") &
strings_pid=$!

extended_report start
link_stats
link_every=6   # polls between link_stats blocks: 6 x 5 s = 30 s

start=$(date +%s); prev=""; i=0
last_progress=-1
while [ -d "$out" ]; do
	now=$(date +%s)
	[ $((now - start)) -ge "$duration" ] && break
	elapsed=$((now - start))
	progress=$((elapsed * 100 / duration))
	if [ "$progress" -ne "$last_progress" ] && [ $((i % heartbeat)) -eq 0 ]; then
		remaining=$(((duration - elapsed + 59) / 60))
		minutes_done=$((elapsed / 60))
		echo "$(date) STATE=POSTBOOT_CAPTURE_PROGRESS elapsed_seconds=$elapsed total_seconds=$duration progress=$progress remaining_minutes=$remaining" >> "$status_file" 2>/dev/null
		echo "$(date) ЭТАП 5/5: контроль после перезагрузки — ${minutes_done}/20 мин.; флешку не вынимайте, если хотите отдать логи на разбор." >> "$status_file" 2>/dev/null
		last_progress="$progress"
	fi
	cur=$(ap_state_line)
	sta_count="$(echo "$cur" | bb awk '{ for (i = 1; i <= NF; i++) if ($i ~ /^hostapd_sta=[0-9]+$/) { sub("hostapd_sta=", "", $i); print $i; exit } }')"
	if [ "${sta_count:-0}" -gt 0 ] && [ ! -s "$out/PHONE_ASSOCIATED" ]; then
		echo "$(date) hostapd_sta=$sta_count" > "$out/PHONE_ASSOCIATED"
		echo "$(date) STATE=PHONE_ASSOCIATED hostapd_sta=$sta_count output=${out##*/}" >> "$status_file" 2>/dev/null
	fi
	if [ "$cur" != "$prev" ]; then
		echo "$(date +%H:%M:%S) CHANGE $cur" >> "$timeline"
		snapshot "change"
		prev="$cur"
	elif [ $((i % heartbeat)) -eq 0 ]; then
		echo "$(date +%H:%M:%S) $cur" >> "$timeline"
	fi
	[ $((i % link_every)) -eq 0 ] && [ "$i" -gt 0 ] && link_stats
	i=$((i + 1))
	size=$(bb wc -c < "$out/logcat_live.txt" 2>/dev/null)
	[ "${size:-0}" -gt "$max_log" ] && kill "$lc" 2>/dev/null
	sleep "$poll"
done

kill "$lc" 2>/dev/null
[ -d "$out" ] || exit 0
snapshot "end"
link_stats
extended_report end
logcat -d -v threadtime -b main -b system > "$out/logcat_end.txt" 2>&1
copy_app_logs "$out/app_logs_end"
# Again at the end: the driver's lines about the 5 GHz start come after the copy done.sh made.
copy_vendor_store "$out/store_end"
echo "$(date +%H:%M:%S) DONE" >> "$timeline"

wait_for_strings_report() {
	waited=0
	while [ ! -f "$out/strings_report.done" ]; do
		[ "$waited" -lt 300 ] || { kill "$strings_pid" 2>/dev/null; return 1; }
		sleep 10
		waited=$((waited + 10))
	done
	return 0
}

package_version_code() {
	dumpsys package "$app_id" 2>/dev/null | bb awk '
		/versionCode=/ {
			split($0, fields, "versionCode=")
			split(fields[2], value, " ")
			print value[1]
			exit
		}'
}

verify_postboot() {
	config="$wifidir/hostapd.conf"
	active_channel="$(wl chanspec 2>/dev/null | bb tr '\n' ' ')"
	[ -n "$active_channel" ] || active_channel="$(wl channel 2>/dev/null | bb tr '\n' ' ')"
	phone_seen=0
	[ -s "$out/PHONE_ASSOCIATED" ] && phone_seen=1
	app_ok=0; wifi_ok=0; helper_ok=0
	[ "$(package_version_code)" = "$app_version" ] && app_ok=1
	if bb grep -q 'COMMUNITY_AP_BAND_WRAPPER_V1' /system/bin/hostapd 2>/dev/null && \
		ps | bb grep -q '[h]ostapd' && bb grep -q '^hw_mode=a$' "$config" && \
		bb grep -q "^channel=$channel$" "$config" && \
		echo "$active_channel" | bb grep -qE "(^|[^0-9])$channel([^0-9]|$)"; then
		wifi_ok=1
	fi
	if ! pm path "$helper_id" 2>/dev/null | bb grep -q '^package:'; then helper_ok=1; fi
	if [ "$app_ok" = 1 ] && [ "$wifi_ok" = 1 ] && [ "$helper_ok" = 1 ]; then
		if [ "$phone_seen" = 1 ]; then
			echo "$(date) STATE=READY_TO_USE channel=$channel phone_seen=1 app_version=$app_version"
			echo "$(date) ГОТОВО: канал 5 ГГц $channel подтверждён, OH Coolray versionCode=$app_version установлен, телефон подключался. Можно пользоваться."
		else
			echo "$(date) STATE=READY_CONNECT_PHONE channel=$channel phone_seen=0 app_version=$app_version"
			echo "$(date) 5 ГГц и OH Coolray проверены. Телефон не был замечен: настройте OH Coolray по инструкции README_RU.txt из архива, дождитесь Android Auto и, если нужны логи, выньте и снова вставьте флешку."
			if [ -e "$usb/_$hook" ] && [ ! -e "$usb/$hook" ]; then
				mv "$usb/_$hook" "$usb/$hook" 2>/dev/null
			fi
		fi
	else
		fallback=0
		[ -f "$wifidir/community_ap_band.failed" ] && fallback=1
		echo "$(date) STATE=CHECK_REQUIRED channel=$channel wifi_ok=$wifi_ok app_ok=$app_ok helper_removed=$helper_ok active_channel=$active_channel phone_seen=$phone_seen fell_back_to_24ghz=$fallback"
		echo "$(date) Нужна проверка: автоматическая проверка не подтвердила все условия. Диагностика сохранена в ${out##*/}."
	fi
}

if ! wait_for_strings_report; then
	echo "$(date) STATE=WARNING strings_report_timeout=300" >> "$status_file" 2>/dev/null
	 echo "strings_report did not finish within five minutes after capture." >> "$out/strings_timeout.txt"
fi
verify_postboot >> "$status_file"
echo "$(date) STATE=POSTBOOT_CAPTURE_DONE output=${out##*/}" >> "$status_file" 2>/dev/null
echo "done $(date)" > "$out/DONE"
sync

