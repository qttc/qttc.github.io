#!/system/bin/sh
export PATH=/sbin:/system/sbin:/system/xbin:/system/bin
mount -o remount,rw /system /system
rm -rf /system/app/AutoKit.apk
rm -rf /mnt/udisk2/b832bc61472727635baffcf25dd28e9f239273e2
sync
sleep 10
reboot
