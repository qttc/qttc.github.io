#!/system/bin/sh

#--- Initialization -------------------------------------------------------------#

script="Package Install v2.8.20250329"
source $usb/dwutils.sh

#--- Main Code ------------------------------------------------------------------#

ScriptStarted

if [[ $swver == "05.06.02000.H40.00022" ]]; then
	usbbase="$usb/H40.00022"
	timestamp=1625301572 #2021-07-03 08:39
elif [[ $swver == "05.07.03000.H50.00020" ]]; then
	usbbase="$usb/H50.00020"
	timestamp=1638778902 #2021-12-06 08:21:42
elif [[ $swver == "05.07.04000.H50.00022" ]]; then
	usbbase="$usb/H50.00022"
	timestamp=""
elif [[ $swver == "05.07.06000.H50.00032" ]]; then
	usbbase="$usb/H50.00032"
	timestamp=1645709460 #2022-02-24 13:31
elif [[ $swver == "05.07.08000.H50.00009" ]]; then
	usbbase="$usb/H50.00009"
	timestamp=1684706700 #2023-05-21 22:05
else
	Log "This software version is not supported"
	ScriptFinished
	exit 1
fi

RemountSystemRW
RestoreSysApp KC2_IPKServer com.neusoft.shockwave.instrumentserver "IPK Server" $timestamp
RemountSystemRO

ScriptFinished

#--- End of File ----------------------------------------------------------------#
