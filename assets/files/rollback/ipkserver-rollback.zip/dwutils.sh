#!/system/bin/sh

#--------------------------------------------------------------------------------#

dwutils="DWUtils v1.2.20240811"
swver=$(getprop ro.build.id)
sysapp="/system/app"
usbbase=$usb

#--------------------------------------------------------------------------------#
function Log {
	echo "$@"
}
#--------------------------------------------------------------------------------#
# Parameters:
#	- Source file/dir name/mask
#	- Path to target directory
#	- Access rights (chmod) [optional]
#	- File date/time (time_t) [optional]
#
function CopyFromUsb {
	local src dst dir_created
	if [[ ! -d $2 ]]; then
		mkdir -p $2 && Log "created $2"
		dir_created=1
	fi
	for src in $usbbase/$1; do
		dst="$2/${src##*/}"
		if [[ -d $src ]]; then
			cp -rf $src $2/ && Log "copied $src/ -> $dst/"
			if [[ $3 ]]; then chmod -R $3 $dst; fi
			if [[ $4 ]]; then touch -t $4 $dst; fi
		elif [[ -f $src ]]; then
			cp -fv $src $2/
			if [[ $3 ]]; then chmod    $3 $dst; fi
			if [[ $4 ]]; then touch -t $4 $dst; fi
		fi
	done
	if [[ $dir_created && $4 ]]; then touch -t $4 $2; fi
}
#--------------------------------------------------------------------------------#
# Parameters:
#	- File/dir paths/masks
#
function Delete {
	local item
	for item in $@; do
		if [[ -d $item ]]; then
			rm -rf $item/ && Log "deleted $item/"
		elif [[ -f $item || -h $item ]]; then
			rm -f $item && Log "deleted $item"
		fi
	done
}
#--------------------------------------------------------------------------------#
# Parameters:
#	- Source file/dir path
#	- New name
#
function Rename {
	mv $1 ${1%/*}/$2 && Log "renamed $1 -> $2"
}
#--------------------------------------------------------------------------------#
# Parameters:
#	- File date/time (time_t)
#	- File/dir paths/masks
#
function SetDateTime {
	local item timet="$1"
	shift
	for item in $@; do
		if [[ -e $item || -h $item ]]; then
			touch -l -t $timet $item && Log "settime $item -> $timet"
		fi
	done
}
#--------------------------------------------------------------------------------#
# Parameters:
#	- Android AppID
#
function IsUserAppInstalled {
	ls /data/app/$1-?.apk &>/dev/null
}
#--------------------------------------------------------------------------------#
# Parameters:
#	- Path to directory with APKs
#	- Log message
#
function InstallUserApps {
	local app
	if [[ -d $1 ]]; then
		Log "Installing $2"
		for app in $1/*.apk; do
			pm install -f -r "$app"
		done
	fi
}
#--------------------------------------------------------------------------------#
function UninstallUserApps {
	local apps=$(pm list packages -3)
	if [[ $apps ]]; then
		Log "Deleting all user applications"
		for app in $apps; do
			Log "\tpkg: ${app:8}"
			pm uninstall ${app:8}
		done
	fi
}
#--------------------------------------------------------------------------------#
# Parameters:
#	- Source file/dir path
#
function GetOwner {
	lsa=( $(ls -ld $1) )
	echo "${lsa[1]}:${lsa[2]}"
}
#--------------------------------------------------------------------------------#
# Parameters:
#	- Path to directory with packages data
#	- Android App ID [optional]
#
function RestoreAppData {
	if [[ $# -eq 1 && -d $1 ]]; then
		local app
		for app in $(ls $1); do
			RestoreAppData $1 $app
		done
	elif [[ $# -ge 2 && -d $1/$2 && -d /data/data/$2 ]]; then
		local own srcdir dstdir srcfile dstfile
		own=$(GetOwner /data/data/$2)
		for srcdir in $1/$2/*; do
			if [[ -d $srcdir ]]; then
				Log "Restroring $2 data"
				dstdir="/data/data/$2/${srcdir##*/}"
				if [[ ! -d $dstdir ]]; then
					mkdir $dstdir && Log "created $dstdir"
					chown $own $dstdir
					chmod 771  $dstdir
				fi
				for srcfile in $srcdir/*; do
					dstfile="$dstdir/${srcfile##*/}"
					if [[ -f $srcfile ]] && [[ ! -f $dstfile || $3 ]]; then
						cp -fpv $srcfile $dstdir/
						chown $own $dstfile
						chmod 660  $dstfile
					fi
				done
			fi
		done
	else
		return 1
	fi
}
#--------------------------------------------------------------------------------#
# Parameters:
#	- System APK name
#	- Android App ID
#	- App description [optional]
#
function DeleteSysApp {
	if [[ -f $sysapp/$1.apk ]]; then
		Log "Deleting ${3-$1} (system)"
		#pm clear $2
		Delete	$sysapp/$1.{apk,odex} \
				/data/app-lib/$1 \
				/data/dalvik-cache/system@app@$1.apk@classes.dex \
				/data/data/$2 \
				/sdcard/Android/data/$2 \
				/sdcard/xsf/log/$2
		need_reboot=1
	fi
}
#--------------------------------------------------------------------------------#
# Parameters:
#	- Android App ID
#	- App description [optional]
#
function EnableSysApp {
	if [[ $(pm list packages -d -s $1) ]]; then
		Log "Enabling system ${2-$1}"
		pm enable $1
	fi
}
#--------------------------------------------------------------------------------#
# Parameters:
#	- APK name
#	- Android App ID
#	- App description [optional]
#
function MoveSysAppToData {
	if [[ -f $sysapp/$1.apk ]]; then
		if IsUserAppInstalled $2; then
			Log "${3-$1} (user) already installed"
		else
			Log "Reinstalling ${3-$1} as user app"
			pm install -f -r $sysapp/$1.apk
			local filename="/data/app/$2-1.apk"
			if [ ! -f $filename ]; then
				cp -fpv $sysapp/$1.apk $filename
				chown system:system $filename
			fi
		fi
		Delete $sysapp/$1.apk
		need_reboot=1
	fi
}
#--------------------------------------------------------------------------------#
# Parameters:
#	- Source file name
#	- Path to target directory
#	- File description [optional]
#
function ReplaceSysFile {
	if [[ -f $usbbase/$1 ]]; then
		if [[ -f $2/$1 ]] \
		   && cmp $usbbase/$1 $2/$1 &>/dev/null; then
			Log	"Skip replacing ${3-$1}, as it's already modified"
		else
			local action
			if [[ -f $2/$1 ]]; then action="Replacing"; else action="Adding"; fi
			Log "$action ${3-$1}"
			CopyFromUsb $1 $2 644
		fi
	fi
}
#--------------------------------------------------------------------------------#
# Parameters:
#	- APK name
#	- Android App ID [optional]
#	- App description [optional]
#
function ReplaceSysApp {
	if [[ -f $usbbase/$1.apk ]]; then
		if [[ -f $sysapp/$1.apk && ! -f $sysapp/$1.odex ]] \
		   && cmp $usbbase/$1.apk $sysapp/$1.apk &>/dev/null; then
			Log	"Skip replacing ${3-$1}, as it's already modified"
		else
			local action
			if [[ -f $sysapp/$1.apk ]]; then action="Replacing"; else action="Adding"; fi
			Log "$action ${3-$1}"
			Delete	$sysapp/$1.odex \
					/data/app-lib/$1 \
					/data/dalvik-cache/system@app@$1.apk@classes.dex
			if [[ -n $2 ]]; then
				Delete /sdcard/xsf/log/$2
			fi
			CopyFromUsb "$1.{apk,odex}" $sysapp 644
			if [[ -d $usbbase/app-lib/$1 ]]; then
				CopyFromUsb app-lib/$1 /data/app-lib 755
				busybox chown -Rv 1000:1000 /data/app-lib/$1
			fi
			need_reboot=1
		fi
	fi
}
#--------------------------------------------------------------------------------#
# Parameters:
#	- Source file name
#	- Path to target directory
#	- File description [optional]
#	- File date/time (time_t) [optional]
#
function RestoreSysFile {
	if [[ -f $usbbase/$1 ]]; then
		if [[ -f $2/$1 ]] \
		   && cmp $usbbase/$1 $2/$1 &>/dev/null; then
			Log	"Skip restoring ${3-$1}, as it's not modified"
		else
			Log "Restoring stock ${3-$1}"
			CopyFromUsb $1 $2 644 $4
		fi
	fi
}
#--------------------------------------------------------------------------------#
# Parameters:
#	- APK name
#	- Android App ID [optional]
#	- App description [optional]
#	- File date/time (time_t) [optional]
#
function RestoreSysApp {
	if [[ -f $usbbase/$1.apk ]]; then
		if [[ -f $sysapp/$1.apk && -f $sysapp/$1.odex ]] \
		   && cmp $usbbase/$1.apk  $sysapp/$1.apk  &>/dev/null \
		   && cmp $usbbase/$1.odex $sysapp/$1.odex &>/dev/null; then
			Log	"Skip restoring ${3-$1}, as it's not modified"
		else
			Log "Restoring stock ${3-$1}"
			Delete	$sysapp/$1.odex \
					/data/app-lib/$1 \
					/data/dalvik-cache/system@app@$1.apk@classes.dex
			if [[ -n $2 ]]; then
				Delete /sdcard/xsf/log/$2
			fi
			CopyFromUsb "$1.{apk,odex}" $sysapp 644 $4
			need_reboot=1
		fi
	fi
}
#--------------------------------------------------------------------------------#
# Parameters:
#	- Global setting name
#	- Android App ID
#
function SettingsSubscribe {
	local list=$(settings get secure $1)
	if [[ -z $list || $list == "null" ]]; then
		Log "settings put secure $1 $2"
		settings put secure $1 $2
	elif [[ ! $list == *$2* ]]; then
		Log "settings put secure $1 $list:$2"
		settings put secure $1 $list:$2
	fi
}
#--------------------------------------------------------------------------------#
# Parameters:
#	- Global setting name
#	- Android App ID
#
function SettingsUnsubscribe {
	local list=$(settings get secure $1)
	if [[ "$list" == "$2" ]]; then
		echo "settings put secure $1 null"
		settings put secure $1 ""
	elif [[ "$list" == *":$2"* ]]; then
		echo "settings put secure $1 ${list/:$2/}"
		settings put secure $1 ${list/:$2/}
	elif [[ "$list" == *"$2:"* ]]; then
		echo "settings put secure $1 ${list/$2:/}"
		settings put secure $1 ${list/$2:/}
	fi
}
#--------------------------------------------------------------------------------#
function RemountSystemRO {
	Log "Remounting system partition read-only"
	mount -o remount,ro /system
}
#--------------------------------------------------------------------------------#
function RemountSystemRW {
	Log "Remounting system partition for writing"
	mount -o remount,rw /system
}
#--------------------------------------------------------------------------------#
function Uptime {
	local t=$(uptime)
	echo ${t:9:8}
}
#--------------------------------------------------------------------------------#
function ScriptStarted {
	exec >> $usb/$(date +%Y%m%d-%H%M).log 2>&1
	Log "Script: $script"
	Log "DWUtils: $dwutils"
	Log "Headunit software: $swver"
	Log "Starting uptime: $(Uptime)"
	am start -n com.android.settings/com.android.settings.SubSettings -e :android:show_fragment com.android.settings.DeviceInfoSettings >/dev/null
}
#--------------------------------------------------------------------------------#
function ScriptFinished {
	Log "Finishing uptime: $(Uptime)"
	if [[ $need_reboot ]]; then
		filename="b832bc61472727635baffcf25dd28e9f239273e2"
		Rename $usb/$filename _$filename
		sync
		sleep 5
		Log "Rebooting"
		reboot
	else
		am force-stop com.android.settings
	fi
}
#--- End of File ----------------------------------------------------------------#
