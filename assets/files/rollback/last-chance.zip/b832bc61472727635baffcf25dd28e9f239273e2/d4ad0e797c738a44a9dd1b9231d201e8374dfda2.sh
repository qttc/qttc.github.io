
#!/system/bin/sh

export PATH=/sbin:/system/sbin:/system/xbin:/system/bin

mount /system
mount -o rw,remount /system

am broadcast -a android.intent.action.MASTER_CLEAR

echo "SUCCESS" >> /mnt/udisk1/USBDETECTED.log

sync