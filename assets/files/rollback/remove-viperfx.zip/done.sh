#!/system/bin/sh

#--- Initialization -------------------------------------------------------------#

script="Uninstall ViPER FX v1.1.20240102"
sysapp="/system/app"
usb="/udisk/single"

#--- Functions ------------------------------------------------------------------#

function Log {
	echo "$@"
}

function CopyFromUsb {
	local src dst dir_created
	if [[ ! -d $2 ]]; then
		mkdir -p $2 && Log "created $2"
		dir_created=1
	fi
	for src in $usb/$1; do
		dst="$2/${src##*/}"
		if [[ -d $src ]]; then
			cp -rf $src $2/ && Log "copied $src/ -> $dst/"
			if [[ $3 ]]; then chmod -R $3 $dst; fi
			if [[ $4 ]]; then touch -t $4 $dst; fi
		elif [[ -f $src ]]; then
			cp -fv $src $2/
			if [[ $3 ]]; then chmod    $3 $dst; fi
			if [[ $4 ]]; then touch -t $4 $dst; fi
		fi
	done
	if [[ $dir_created && $4 ]]; then touch -t $4 $2; fi
}

function Delete {
	local item
	for item in $@; do
		if [[ -d $item ]]; then
			rm -rf $item/ && Log "deleted $item/"
		elif [[ -f $item || -h $item ]]; then
			rm -f $item && Log "deleted $item"
		fi
	done
}

function Rename {
	mv $1 ${1%/*}/$2 && Log "renamed $1 -> $2"
}

function Uptime {
	local t=$(uptime)
	echo ${t:9:8}
}

function ScriptStarted {
	exec > $usb/$(date +%Y%m%d-%H%M).log 2>&1
	Log "Script: $script"
	Log "Headunit software: $(getprop ro.build.id)"
	Log "Starting uptime: $(Uptime)"
	am start -n com.android.settings/com.android.settings.SubSettings -e :android:show_fragment com.android.settings.DeviceInfoSettings >/dev/null
}

function ScriptFinished {
	Log "Finishing uptime: $(Uptime)"
	if [[ $need_reboot ]]; then
		filename="b832bc61472727635baffcf25dd28e9f239273e2"
		Rename $usb/$filename _$filename
		sync
		sleep 5
		Log "Rebooting"
		reboot
	else
		am force-stop com.android.settings
	fi
}

#--- Main Code ------------------------------------------------------------------#

ScriptStarted

#Монтируем системный раздел для перезаписи
Log "Mounting system partition"
mount -o remount,rw /system

Удаляем пользовательский Viper
package="com.vipercn.viper4android_v2"
if [[ $(pm list packages -3 $package) ]]; then
	Log "Deleting ViPER4Android FX (user)"
	pm pm uninstall $package
fi

#Удаляем системный Viper
filename="ViPER4Android_4.x.apk"
if [[ -f $sysapp/$filename ]]; then
	Log "Deleting ViPER4Android FX (system)"
	Delete	$sysapp/$filename \
			/data/app-lib/$package \
			/data/dalvik-cache/system@app@$filename@classes.dex \ 
			/data/data/$package \
			/sdcard/Android/data/$package
	need_reboot=1
fi

#Подчищаем хвосты ViperFX
filename="audio_effects.conf"
if [[ -f $usb/$filename ]] && ! cmp $usb/$filename /etc/$filename >/dev/null 2>&1; then
	CopyFromUsb $filename /etc 644
	CopyFromUsb $filename /vendor/etc 644
fi
filename="/system/lib/soundfx/libv4a_fx_ics.so"
if [[ -f $filename ]]; then
	Log "Removind ViPER driver"
	Delete $filename
	need_reboot=1
fi
Delete /sdcard/ViPER4Android

ScriptFinished

#--- End of File ----------------------------------------------------------------#
