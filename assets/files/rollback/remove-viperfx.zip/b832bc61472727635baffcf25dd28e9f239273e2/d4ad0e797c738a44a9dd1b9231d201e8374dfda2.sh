#!/system/bin/sh
script_path="/udisk/single/done.sh"
chmod +x $script_path
. "$script_path"